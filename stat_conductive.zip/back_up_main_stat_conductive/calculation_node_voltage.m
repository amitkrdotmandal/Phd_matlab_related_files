clc;clear all;


left_side_dim_to_apply_voltage=15;
right_side_dim_to_apply_voltage=160;


file_name="resistors_for_CNTs.xlsx";
resistors_for_CNTs_values=xlsread(file_name);
size_resistors_for_CNTs_values=size(resistors_for_CNTs_values);

file_name="resistors_for_tunnels.xlsx";
resistors_for_tunnel_values=xlsread(file_name);
size_resistors_for_tunnels_values=size(resistors_for_tunnel_values);




for i=1:size_resistors_for_CNTs_values(1)
    resistors(i,:)=resistors_for_CNTs_values(i,1:2);
    resi=resistors_for_CNTs_values(i,3:8);
    resistance(i)=function_CNT_resistance(resi);
       
    
end




for i=1:size_resistors_for_tunnels_values(1)
    resistors(size_resistors_for_CNTs_values(1)+i,:)=resistors_for_tunnel_values(i,1:2);
    resi=resistors_for_tunnel_values(i,3:8);
    resistance(size_resistors_for_CNTs_values(1)+i)=function_tunnel_resistance(resi);
       
    
end




min_resistance=min(resistance);
if min_resistance<=0

    sort_resistance=sort(resistance);
    for i=1:length(resistance)
        if sort_resistance(i)>0
            notify_i=i;
            break
        end
    end
    acceptable_resistance=sort_resistance(notify_i)/100;
    for i=1:length(resistance)
        if resistance(i)<=0
            resistance(i)=acceptable_resistance;
        end
    end
    
end
resistance;
resistors;








size_resistors=size(resistors);     %need not necessary to add
allow_to_carry=1;                   %need not necessary to add
for i=1:size_resistors(1)           %need not necessary to add
    to_compare_1=resistors(i,1);    %need not necessary to add
    to_compare_2=resistors(i,2);    %need not necessary to add
    for j=i+1:size_resistors(1)     %need not necessary to add    
        if to_compare_1==resistors(j,1) && to_compare_2==resistors(j,2)  %need not necessary to add
            allow_to_carry=0;       %need not necessary to add
            break
        end
    end
    if allow_to_carry==0
        break
    end
end                  %need not necessary to add,upto this






%if allow_to_carry==1


node_vol=NaN(1,max(max(resistors)));

for i=1:size_resistors_for_CNTs_values(1)
    a_1=resistors_for_CNTs_values(i,3);
    if a_1<left_side_dim_to_apply_voltage
        node_vol(resistors_for_CNTs_values(i,1))=50;
    end
    if a_1>right_side_dim_to_apply_voltage
        node_vol(resistors_for_CNTs_values(i,1))=0;
    end
    
    
    
    
    
    
    
    a_2=resistors_for_CNTs_values(i,4);
    if a_2<left_side_dim_to_apply_voltage
        node_vol(resistors_for_CNTs_values(i,2))=50;
    end
    if a_2>right_side_dim_to_apply_voltage
        node_vol(resistors_for_CNTs_values(i,2))=0;
    end
        
end


node_vol




[is_searched_perticular_node,is_voltage_present] = function_to_contributing_nodes(resistance,resistors,node_vol);

for i=1:length(node_vol)
    if is_searched_perticular_node(i)==0 && is_voltage_present(i)==0
        node_vol(i)=0;
    end
end

node_vol;

%solved_node_vol=KCL_function(resistors,resistance,node_vol)

solved_node_vol=KCL_function(resistors,resistance,node_vol)

for i=1:length(node_vol)
    if is_searched_perticular_node(i)==0 && is_voltage_present(i)==0
        solved_node_vol(i)=NaN;
    end
end



for i=1:size_resistors_for_CNTs_values(1)
    ax=resistors_for_CNTs_values(i,3:4);
    ay=resistors_for_CNTs_values(i,5:6);
    az=resistors_for_CNTs_values(i,7:8);
    plot3(ax,ay,az,'m','LineWidth',2);
    hold on;
   
end

for i=1:size_resistors_for_tunnels_values(1)
    ax=resistors_for_tunnel_values(i,3:4);
    ay=resistors_for_tunnel_values(i,5:6);
    az=resistors_for_tunnel_values(i,7:8);
    plot3(ax,ay,az,'b');
    hold on;
   
end

for i=1:length(solved_node_vol)
    for j=1:size_resistors_for_CNTs_values(1)
        if i==resistors_for_CNTs_values(j,1)
            ax=resistors_for_CNTs_values(j,3);
            ay=resistors_for_CNTs_values(j,5);
            az=resistors_for_CNTs_values(j,7);
            break
        end
        
        if i==resistors_for_CNTs_values(j,2)
            ax=resistors_for_CNTs_values(j,4);
            ay=resistors_for_CNTs_values(j,6);
            az=resistors_for_CNTs_values(j,8);
            break
        end
    end
    text(ax,ay,az,'\leftarrow '+string(round(solved_node_vol(i))))
end


%else
%    'parallel resistance found'
%end



















