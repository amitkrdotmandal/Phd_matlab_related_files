function [resistance] = function_CNT_resistance(resi)
area=2;
length=sqrt((resi(1)-resi(2))^2+(resi(3)-resi(4))^2+(resi(5)-resi(6))^2);
resistivity=10;
resistance=resistivity*length/area;
end