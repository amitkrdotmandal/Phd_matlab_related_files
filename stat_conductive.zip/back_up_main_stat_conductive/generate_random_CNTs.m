clc; clear all;

delete_=1
if delete_==1
    if exist('CNT_data_for_3d.xlsx', 'file')==2
        delete('CNT_data_for_3d.xlsx');
    end
    
    if exist('tunnel_data_for_3d.xlsx', 'file')==2
         delete('tunnel_data_for_3d.xlsx');
    end
    
    if exist('resistors_for_CNTs.xlsx', 'file')==2
         delete('resistors_for_CNTs.xlsx');
    end
    
     if exist('resistors_for_tunnels.xlsx', 'file')==2
         delete('resistors_for_tunnels.xlsx');
    end
end



no_f_CNTs=50;
length_of_CNT=60;
length_box_x=200;
length_box_y=200;
length_box_z=200;
count_zero_len=0;

rand(1)
k=1;
for i=1:no_f_CNTs
ini_pt_x=length_box_x*rand(1);
ini_pt_y=length_box_y*rand(1);
ini_pt_z=length_box_z*rand(1);

P_last_pt_x=ini_pt_x+length_of_CNT*rand(1)*randi([-1 1]);
P_last_pt_y=ini_pt_y+length_of_CNT*rand(1)*randi([-1 1]);
P_last_pt_z=ini_pt_z+length_of_CNT*rand(1)*randi([-1 1]);
P_len=sqrt((ini_pt_x-P_last_pt_x)^2+(ini_pt_y-P_last_pt_y)^2+(ini_pt_z-P_last_pt_z)^2);
if P_len>0

last_pt_x=ini_pt_x-(ini_pt_x-P_last_pt_x)*length_of_CNT/P_len;
last_pt_y=ini_pt_y-(ini_pt_y-P_last_pt_y)*length_of_CNT/P_len;
last_pt_z=ini_pt_z-(ini_pt_z-P_last_pt_z)*length_of_CNT/P_len;

len=sqrt((ini_pt_x-last_pt_x)^2+(ini_pt_y-last_pt_y)^2+(ini_pt_z-last_pt_z)^2);

ax2=[ini_pt_x last_pt_x];
ay2=[ini_pt_y last_pt_y];
az2=[ini_pt_z last_pt_z];



to_save(k,1:2)=ax2;
to_save(k,3:4)=ay2;
to_save(k,5:6)=az2;
k=k+1;

plot3(ax2,ay2,az2);
hold on
else
    count_zero_len=count_zero_len+1;
end

end
count_zero_len

filename="CNT_data_for_3d.xlsx";
xlswrite(filename,to_save)