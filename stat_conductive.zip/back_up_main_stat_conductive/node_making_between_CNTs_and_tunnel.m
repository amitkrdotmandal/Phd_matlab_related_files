clc; clear all;
file_name="tunnel_data_for_3d.xlsx";
values_modified=xlsread(file_name);
size_values=size(values_modified);




file_name="CNT_data_for_3d.xlsx";
values_CNTs=xlsread(file_name);
size_values_CNTs=size(values_CNTs);


total_global_points=0;
total_resistors_for_CNTs=0;
for CNT_no=1:size_values_CNTs(1)
    
CNT_no
brak_at_first=1;
for i=1:size_values(1)
    CNT_connection(1,:)=values_modified(i,8:9);
    if CNT_connection(1,1)==CNT_no
        break
    end
    brak_at_first=brak_at_first+1;
end

brak_at_first;
clear present_at_second_tunnel_no
present_at_second_tunnel_no=[NaN];
k=1;
for i=1:brak_at_first-1
    if values_modified(i,9)==CNT_no
        present_at_second_tunnel_no(k)=i;
        k=k+1;
    end
end
present_at_second_tunnel_no;



clear present_at_first_tunnel_no
present_at_first_tunnel_no=[NaN];
k=1;
for i=brak_at_first:size_values(1)
    if values_modified(i,8)==CNT_no
        present_at_first_tunnel_no(k)=i;
        k=k+1;
    end
end
present_at_first_tunnel_no;







isnan_present_at_second_tunnel_no=isnan(present_at_second_tunnel_no(1));
isnan_present_at_first_tunnel_no=isnan(present_at_first_tunnel_no(1));


clear distance_at_second_tunnel_no
distance_at_second_tunnel_no=[NaN];
if isnan_present_at_second_tunnel_no==0
    length_present_at_second_tunnel_no=length(present_at_second_tunnel_no);
    k=1;
    for i=1:length_present_at_second_tunnel_no
        distance_at_second_tunnel_no(k)=sqrt((values_CNTs(CNT_no,1)-values_modified(present_at_second_tunnel_no(i),2))^2+(values_CNTs(CNT_no,3)-values_modified(present_at_second_tunnel_no(i),4))^2+(values_CNTs(CNT_no,5)-values_modified(present_at_second_tunnel_no(i),6))^2);
        k=k+1;
        
    end
end
distance_at_second_tunnel_no;



clear distance_at_first_tunnel_no
distance_at_first_tunnel_no=[NaN];
if isnan_present_at_first_tunnel_no==0
    length_present_at_first_tunnel_no=length(present_at_first_tunnel_no);
    k=1;
    for i=1:length_present_at_first_tunnel_no
        distance_at_first_tunnel_no(k)=sqrt((values_CNTs(CNT_no,1)-values_modified(present_at_first_tunnel_no(i),1))^2+(values_CNTs(CNT_no,3)-values_modified(present_at_first_tunnel_no(i),3))^2+(values_CNTs(CNT_no,5)-values_modified(present_at_first_tunnel_no(i),5))^2);
        k=k+1;
        
    end
end
distance_at_first_tunnel_no;



clear assembled_distance_at_tunnel
clear assembled_present_at_tunnel_no
clear assembled_present_at_first1_or_second0_CNT  %%%%% if second it will be zero, if first it will be one 
assembled_distance_at_tunnel=[NaN];
assembled_present_at_tunnel_no=[NaN];
assembled_present_at_first1_or_second0_CNT=[NaN];   %%%%% if second it will be zero, if first it will be one 



if isnan_present_at_second_tunnel_no==0 && isnan_present_at_first_tunnel_no==1
    length_present_at_second_tunnel_no=length(present_at_second_tunnel_no);
    k=1;
    for i=1:length_present_at_second_tunnel_no
        assembled_distance_at_tunnel(k)=distance_at_second_tunnel_no(i);
        assembled_present_at_tunnel_no(k)=present_at_second_tunnel_no(i);
        assembled_present_at_first1_or_second0_CNT(k)=0;
        k=k+1;
        
    end
    
    
    
elseif isnan_present_at_second_tunnel_no==1 && isnan_present_at_first_tunnel_no==0
    length_present_at_first_tunnel_no=length(present_at_first_tunnel_no);
    k=1;
    for i=1:length_present_at_first_tunnel_no
        assembled_distance_at_tunnel(k)=distance_at_first_tunnel_no(i);
        assembled_present_at_tunnel_no(k)=present_at_first_tunnel_no(i);
        assembled_present_at_first1_or_second0_CNT(k)=1;
        k=k+1;
        
    end
    
    
    
elseif isnan_present_at_second_tunnel_no==0 && isnan_present_at_first_tunnel_no==0
    length_present_at_second_tunnel_no=length(present_at_second_tunnel_no);
    k=1;
    for i=1:length_present_at_second_tunnel_no
        assembled_distance_at_tunnel(k)=distance_at_second_tunnel_no(i);
        assembled_present_at_tunnel_no(k)=present_at_second_tunnel_no(i);
        assembled_present_at_first1_or_second0_CNT(k)=0;
        k=k+1;
        
    end
    length_present_at_first_tunnel_no=length(present_at_first_tunnel_no);
    for i=1:length_present_at_first_tunnel_no
        assembled_distance_at_tunnel(k)=distance_at_first_tunnel_no(i);
        assembled_present_at_tunnel_no(k)=present_at_first_tunnel_no(i);
        assembled_present_at_first1_or_second0_CNT(k)=1;
        k=k+1;
        
    end
end

assembled_distance_at_tunnel;
assembled_present_at_tunnel_no;
assembled_present_at_first1_or_second0_CNT;


[sorted_assembled_distance_at_tunnel,I] = sort(assembled_distance_at_tunnel);
sorted_assembled_present_at_tunnel_no=assembled_present_at_tunnel_no(I);
sorted_assembled_present_at_first1_or_second0_CNT=assembled_present_at_first1_or_second0_CNT(I);

sorted_assembled_distance_at_tunnel
sorted_assembled_present_at_tunnel_no
sorted_assembled_present_at_first1_or_second0_CNT






%%%%clearing unwanted matrices
%%%%clearing unwanted matrices
%%%%clearing unwanted matrices
%%%%clearing unwanted matrices


clear present_at_second_tunnel_no
clear distance_at_first_tunnel_no
clear distance_at_second_tunnel_no
clear present_at_first_tunnel_no
clear assembled_distance_at_tunnel
clear assembled_present_at_tunnel_no
clear assembled_present_at_first1_or_second0_CNT




%%%here "sorted_assembled_distance_at_tunnel" is added with "length of the CNT" at last element
%%%here "sorted_assembled_distance_at_tunnel" is added with "length of the CNT" at last element
%%%here "sorted_assembled_distance_at_tunnel" is added with "length of the CNT" at last element
%%%here "sorted_assembled_distance_at_tunnel" is added with "length of the
%%%CNT" at last element first element at zero

isnan_sorted_assembled_distance_at_tunnel=isnan(sorted_assembled_distance_at_tunnel(1));
length_sorted_assembled_distance_at_tunnel=length(sorted_assembled_distance_at_tunnel);
length_of_CNT=sqrt((values_CNTs(CNT_no,1)-values_CNTs(CNT_no,2))^2+(values_CNTs(CNT_no,3)-values_CNTs(CNT_no,4))^2+(values_CNTs(CNT_no,5)-values_CNTs(CNT_no,6))^2);
if isnan_sorted_assembled_distance_at_tunnel==1
    sorted_assembled_distance_at_tunnel(1)=0;
    sorted_assembled_distance_at_tunnel(2)=length_of_CNT;
else
    
    temp_sorted_assembled_distance_at_tunnel=sorted_assembled_distance_at_tunnel;
    for i=1:length_sorted_assembled_distance_at_tunnel
        sorted_assembled_distance_at_tunnel(i+1)=temp_sorted_assembled_distance_at_tunnel(i);
    end
    clear temp_sorted_assembled_distance_at_tunnel
    sorted_assembled_distance_at_tunnel(1)=0;
    sorted_assembled_distance_at_tunnel(length_sorted_assembled_distance_at_tunnel+2)=length_of_CNT;
end
sorted_assembled_distance_at_tunnel





clear local_nodal_points
k=1;
for i=1:length(sorted_assembled_distance_at_tunnel)
    if i==1
        local_nodal_points(i)=k;
    else
        if sorted_assembled_distance_at_tunnel(i-1)==sorted_assembled_distance_at_tunnel(i)
            local_nodal_points(i)=k;
        else
            k=k+1;
            local_nodal_points(i)=k;
        end
    end
end
local_nodal_points;
global_nodal_points=local_nodal_points+total_global_points;
total_global_points=global_nodal_points(length(global_nodal_points));
global_nodal_points

clear global_nodal_cordinates
for i=1:length(sorted_assembled_distance_at_tunnel)
    if i==1
        global_nodal_cordinates(i,:)=[values_CNTs(CNT_no,1) values_CNTs(CNT_no,3) values_CNTs(CNT_no,5)];
    elseif i==length(sorted_assembled_distance_at_tunnel)
        global_nodal_cordinates(i,:)=[values_CNTs(CNT_no,2) values_CNTs(CNT_no,4) values_CNTs(CNT_no,6)];
        
    else
        if sorted_assembled_present_at_first1_or_second0_CNT(i-1)==1
            global_nodal_cordinates(i,:)=[values_modified(sorted_assembled_present_at_tunnel_no(i-1),1) values_modified(sorted_assembled_present_at_tunnel_no(i-1),3) values_modified(sorted_assembled_present_at_tunnel_no(i-1),5)];
        else
            global_nodal_cordinates(i,:)=[values_modified(sorted_assembled_present_at_tunnel_no(i-1),2) values_modified(sorted_assembled_present_at_tunnel_no(i-1),4) values_modified(sorted_assembled_present_at_tunnel_no(i-1),6)];
        end
        
    end
end
global_nodal_cordinates

first_to_be=1;
for i=1:length(sorted_assembled_distance_at_tunnel)
    if i>1
        if global_nodal_points(i-1)~=global_nodal_points(i)
            total_resistors_for_CNTs=total_resistors_for_CNTs+1;
            resistors_for_CNTs(total_resistors_for_CNTs,1)=global_nodal_points(first_to_be);
            resistors_for_CNTs(total_resistors_for_CNTs,2)=global_nodal_points(i);
            resistors_for_CNTs(total_resistors_for_CNTs,3)=global_nodal_cordinates(first_to_be,1);
            resistors_for_CNTs(total_resistors_for_CNTs,4)=global_nodal_cordinates(i,1);
            resistors_for_CNTs(total_resistors_for_CNTs,5)=global_nodal_cordinates(first_to_be,2);
            resistors_for_CNTs(total_resistors_for_CNTs,6)=global_nodal_cordinates(i,2);
            resistors_for_CNTs(total_resistors_for_CNTs,7)=global_nodal_cordinates(first_to_be,3);
            resistors_for_CNTs(total_resistors_for_CNTs,8)=global_nodal_cordinates(i,3);
            
            
            first_to_be=i;
        end
    end
end



isnan_sorted_assembled_present_at_tunnel_no=isnan(sorted_assembled_present_at_tunnel_no(1));
if isnan_sorted_assembled_present_at_tunnel_no==0
for i=1:length(sorted_assembled_present_at_tunnel_no)
    
    if sorted_assembled_present_at_first1_or_second0_CNT(i)==1
        resistors_for_tunnels(sorted_assembled_present_at_tunnel_no(i),1)=global_nodal_points(i+1);
        resistors_for_tunnels(sorted_assembled_present_at_tunnel_no(i),3)=global_nodal_cordinates(i+1,1);
        resistors_for_tunnels(sorted_assembled_present_at_tunnel_no(i),5)=global_nodal_cordinates(i+1,2);
        resistors_for_tunnels(sorted_assembled_present_at_tunnel_no(i),7)=global_nodal_cordinates(i+1,3);
    else
        resistors_for_tunnels(sorted_assembled_present_at_tunnel_no(i),2)=global_nodal_points(i+1);
        resistors_for_tunnels(sorted_assembled_present_at_tunnel_no(i),4)=global_nodal_cordinates(i+1,1);
        resistors_for_tunnels(sorted_assembled_present_at_tunnel_no(i),6)=global_nodal_cordinates(i+1,2);
        resistors_for_tunnels(sorted_assembled_present_at_tunnel_no(i),8)=global_nodal_cordinates(i+1,3);
        resistors_for_tunnels(sorted_assembled_present_at_tunnel_no(i),9)=values_modified(sorted_assembled_present_at_tunnel_no(i),7);
    end
    
end
end

end

resistors_for_CNTs
resistors_for_tunnels

filename="resistors_for_CNTs.xlsx";
xlswrite(filename,resistors_for_CNTs)

filename="resistors_for_tunnels.xlsx";
xlswrite(filename,resistors_for_tunnels)