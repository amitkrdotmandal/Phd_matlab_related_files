function [resistance] = function_tunnel_resistance(resi)
area=2;
length=sqrt((resi(1)-resi(2))^2+(resi(3)-resi(4))^2+(resi(5)-resi(6))^2);
h=125*1000;
e=12000;
m=45;
lamda=11;

resistance=h^2*length/(area*e^2*sqrt(2*m*lamda))*exp(4*3.14*length/h*sqrt(2*m*lamda));
end