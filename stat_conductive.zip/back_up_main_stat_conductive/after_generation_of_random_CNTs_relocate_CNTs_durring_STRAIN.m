clc; clear all;
file_name="CNT_data_for_3d";
filee_name=file_name+".xlsx";
values_modified=xlsread(filee_name);
size_values=size(values_modified);


length_of_CNT=40;
length_box_x=200;
length_box_y=200;
length_box_z=200;

NEW_length_box_x=220;
NEW_length_box_y=250;
NEW_length_box_z=length_box_x*length_box_y*length_box_z/NEW_length_box_x/NEW_length_box_y;%%%%%%%%DUE_TO_INCOMPRESSIBILITY


for i=1:size_values(1)
    MID_x=(values_modified(i,1)+values_modified(i,2))/2;
    MID_y=(values_modified(i,3)+values_modified(i,4))/2;
    MID_z=(values_modified(i,5)+values_modified(i,6))/2;
    New_MID_x=NEW_length_box_x/length_box_x*MID_x;
    New_MID_y=NEW_length_box_y/length_box_y*MID_y;
    New_MID_z=NEW_length_box_z/length_box_z*MID_z;
    
    length_CNT=sqrt((values_modified(i,1)-values_modified(i,2))^2+(values_modified(i,3)-values_modified(i,4))^2+(values_modified(i,5)-values_modified(i,6))^2);
    old_x1_x2=(values_modified(i,1)-values_modified(i,2));
    old_y1_y2=(values_modified(i,3)-values_modified(i,4));
    old_z1_z2=(values_modified(i,5)-values_modified(i,6));
    New_x1_x2=old_x1_x2/length_box_x*NEW_length_box_x;
    New_y1_y2=old_y1_y2/length_box_y*NEW_length_box_y;
    New_z1_z2=old_z1_z2/length_box_z*NEW_length_box_z;
    arbitary_length=sqrt(New_x1_x2^2+New_y1_y2^2+New_z1_z2^2);
    New_x1_x2_cnt=New_x1_x2/arbitary_length*length_CNT;
    New_y1_y2_cnt=New_y1_y2/arbitary_length*length_CNT;
    New_z1_z2_cnt=New_z1_z2/arbitary_length*length_CNT;
    New_x1=New_MID_x-New_x1_x2_cnt/2;
    New_x2=New_MID_x+New_x1_x2_cnt/2;
    New_y1=New_MID_y-New_y1_y2_cnt/2;
    New_y2=New_MID_y+New_y1_y2_cnt/2;
    New_z1=New_MID_z-New_z1_z2_cnt/2;
    New_z2=New_MID_z+New_z1_z2_cnt/2;
%     ne_len=sqrt((New_x1-New_x2)^2+(New_y1-New_y2)^2+(New_z1-New_z2)^2)
%     old_ax=values_modified(i,1:2);
%     old_ay=values_modified(i,3:4);
%     old_az=values_modified(i,5:6);
%     plot3(old_ax,old_ay,old_az,'b');
%     hold on;
    
    ax=[New_x1 New_x2];
    ay=[New_y1 New_y2];
    az=[New_z1 New_z2];
    plot3(ax,ay,az,'m');
    hold on;
    

    to_save(i,1:2)=ax;
to_save(i,3:4)=ay;
to_save(i,5:6)=az;
    
    
    

    plot3(MID_x,MID_y,MID_z,'*');
    hold on;
    plot3(New_MID_x,New_MID_y,New_MID_z,'o');
    hold on;
%     plot3([MID_x New_MID_x],[MID_y New_MID_y],[MID_z New_MID_z]);
  
end
file_name=file_name+"_strained";
filee_name=file_name+".xlsx";
xlswrite(filee_name,to_save)