function [plotx,ploty,plotz,length_,in_range] = length_det_function_modification(ax1,ay1,az1,ax2,ay2,az2,cutoff)
   

%ax1=[10 25];
%ay1=[15 -22];
%az1=[0 0];
a1=[ax1(1);ay1(1);az1(1)];
b1=[(ax1(2)-ax1(1));(ay1(2)-ay1(1));(az1(2)-az1(1))];

plot3(ax1,ay1,az1,'g');
hold on


%ax2=[10 110];
%ay2=[0 12];
%az2=[0 0];
a2=[ax2(1);ay2(1);az2(1)];
b2=[(ax2(2)-ax2(1));(ay2(2)-ay2(1));(az2(2)-az2(1))];


plot3(ax2,ay2,az2,'g');
hold on






    
    if cross(b1,b2)==0
        p_len=abs(norm(cross(b1,(a1-a2)))/norm(b1));
        tempo_z=cross(b1,(a1-a2));
        unit_vec=cross(b1,tempo_z)/norm(cross(b1,tempo_z));
    else
    
        p_len=abs(dot(cross(b1,b2),(a1-a2))/norm(cross(b1,b2)));
        unit_vec=(cross(b1,b2))/norm(cross(b1,b2));
    end
A_mat=[(b1(1)+b1(3)) -(b2(1)+b2(3));(b1(2)+b1(3)) -(b2(2)+b2(3))];

if det(A_mat)==0
    A_mat=A_mat+2*10^(-6)*[1 0;0 1];
end

B_mat=[(a2(1)+a2(3))-(a1(1)+a1(3));(a2(2)+a2(3))-(a1(2)+a1(3))];
C_mat=[(unit_vec(1)+unit_vec(3))*p_len;(unit_vec(2)+unit_vec(3))*p_len];

posi_res=inv(A_mat)*(B_mat+C_mat);
%DETER_POSI=abs((a1(3)+posi_res(1)*b1(3))-(a2(3)+posi_res(2)*b2(3)-unit_vec(3)*p_len))

negi_res=inv(A_mat)*(B_mat-C_mat);
%DETER_NEGI=abs((a1(3)+negi_res(1)*b1(3))-(a2(3)+negi_res(2)*b2(3)+unit_vec(3)*p_len))

i1posi_res=a1+posi_res(1)*b1;
i2posi_res=a2+posi_res(2)*b2;
length_varivicationposi_res=sqrt(dot((i1posi_res-i2posi_res),(i1posi_res-i2posi_res)));
err_posi=abs(p_len-length_varivicationposi_res);


i1negi_res=a1+negi_res(1)*b1;
i2negi_res=a2+negi_res(2)*b2;
length_varivicationnegi_res=sqrt(dot((i1negi_res-i2negi_res),(i1negi_res-i2negi_res)));
err_negi=abs(p_len-length_varivicationnegi_res);


if err_posi<err_negi
    actual_res=posi_res;
else
    actual_res=negi_res;
end
i1=a1+actual_res(1)*b1;
i2=a2+actual_res(2)*b2;


length_varification=sqrt(dot((i1-i2),(i1-i2)));
plot3([i1(1) i2(1)],[i1(2) i2(2)],[i1(3) i2(3)]);






toti1=(i1(1)+i1(2)+i1(3));
totP1L1=(ax1(1)+ay1(1)+az1(1));
totP2L1=(ax1(2)+ay1(2)+az1(2));
alphaL1=(toti1-totP1L1)/(totP2L1-totP1L1);


toti2=(i2(1)+i2(2)+i2(3));
totP1L2=(ax2(1)+ay2(1)+az2(1));
totP2L2=(ax2(2)+ay2(2)+az2(2));
alphaL2=(toti2-totP1L2)/(totP2L2-totP1L2);


if alphaL1>=0 && alphaL1<=1 && alphaL2>=0 && alphaL2<=1
    reali1=i1;
    reali2=i2;
elseif alphaL1>=0 && alphaL1<=1 && (alphaL2<0 || alphaL2>1)
    reali1=i1;
    
    
    P1L2dis=sqrt((i2(1)-ax2(1))^2+(i2(2)-ay2(1))^2+(i2(3)-az2(1))^2);
    P2L2dis=sqrt((i2(1)-ax2(2))^2+(i2(2)-ay2(2))^2+(i2(3)-az2(2))^2);
    if P1L2dis<P2L2dis
        reali2=[ax2(1) ay2(1) az2(1)];
    else
        reali2=[ax2(2) ay2(2) az2(2)];
    end
    
elseif (alphaL1<0 || alphaL1>1) && (alphaL2>=0 && alphaL2<=1)
    P1L1dis=sqrt((i1(1)-ax1(1))^2+(i1(2)-ay1(1))^2+(i1(3)-az1(1))^2);
    P2L1dis=sqrt((i1(1)-ax1(2))^2+(i1(2)-ay1(2))^2+(i1(3)-az1(2))^2);
    if P1L1dis<P2L1dis
        reali1=[ax1(1) ay1(1) az1(1)];
    else
        reali1=[ax1(2) ay1(2) az1(2)];
    end
    
    
    reali2=i2;

    
elseif (alphaL1<0 || alphaL1>1) && (alphaL2<0 || alphaL2>1)
    case11=sqrt((ax2(1)-ax1(1))^2+(ay2(1)-ay1(1))^2+(az2(1)-az1(1))^2);
    case12=sqrt((ax2(2)-ax1(1))^2+(ay2(2)-ay1(1))^2+(az2(2)-az1(1))^2);
    case21=sqrt((ax2(1)-ax1(2))^2+(ay2(1)-ay1(2))^2+(az2(1)-az1(2))^2);
    case22=sqrt((ax2(2)-ax1(2))^2+(ay2(2)-ay1(2))^2+(az2(2)-az1(2))^2);
    to_find_min=[case11 case12 case21 case22];
    min_in=min(to_find_min);
    if to_find_min(1)==min_in
        reali1=[ax1(1) ay1(1) az1(1)];
        reali2=[ax2(1) ay2(1) az2(1)];
    elseif to_find_min(2)==min_in
        reali1=[ax1(1) ay1(1) az1(1)];
        reali2=[ax2(2) ay2(2) az2(2)];
    elseif to_find_min(3)==min_in
        reali1=[ax1(2) ay1(2) az1(2)];
        reali2=[ax2(1) ay2(1) az2(1)];
    elseif to_find_min(4)==min_in
        reali1=[ax1(2) ay1(2) az1(2)];
        reali2=[ax2(2) ay2(2) az2(2)];
    end
        
end







length_=sqrt((reali1(1)-reali2(1))^2+(reali1(2)-reali2(2))^2+(reali1(3)-reali2(3))^2);
length_u=[length_ 0];
plotx=[reali1(1) reali2(1)];
ploty=[reali1(2) reali2(2)];
plotz=[reali1(3) reali2(3)];

if length_>cutoff
    in_range=0;
else
    in_range=1;
end
in_range_u=[in_range 0];
return_u=[plotx,ploty,plotz,length_u,in_range_u];
plot3(plotx,ploty,plotz,'m')
end


%unit_vec=(cross(b1,b2))/norm(cross(b1,b2));
%p_len=abs(dot(cross(b1,b2),(a1-a2))/norm(cross(b1,b2)))
%A_mat=[b1(1) -b2(1);b1(2) -b2(2)]
%B_mat=[a2(1)-a1(1);a2(2)-a1(2)];
%C_mat=[unit_vec(1)*p_len;unit_vec(2)*p_len];
%posi_res=inv(A_mat)*(B_mat+C_mat);
%DETER_POSI=abs((a1(3)+posi_res(1)*b1(3))-(a2(3)+posi_res(2)*b2(3)+unit_vec(3)*p_len));

%negi_res=inv(A_mat)*(B_mat-C_mat);
%DETER_NEGI=abs((a1(3)+negi_res(1)*b1(3))-(a2(3)+negi_res(2)*b2(3)+unit_vec(3)*p_len));
%if DETER_POSI<DETER_NEGI
%    actual_res=posi_res;
%else
%    actual_res=negi_res;
%end
%i1=a1+actual_res(1)*b1
%i2=a2+actual_res(2)*b2

%toti1=(i1(1)+i1(2)+i1(3));
%totP1L1=(ax1(1)+ay1(1)+az1(1));
%totP2L1=(ax1(2)+ay1(2)+az1(2));
%alphaL1=(toti1-totP1L1)/(totP2L1-totP1L1);
%if alphaL1>=0 && alphaL1<=1
%    reali1=i1;
%else
%    P1L1dis=sqrt((i1(1)-ax1(1))^2+(i1(2)-ay1(1))^2+(i1(1)-az1(1))^2);
%    P2L1dis=sqrt((i1(1)-ax1(2))^2+(i1(2)-ay1(2))^2+(i1(1)-az1(2))^2);
%    if P1L1dis<P2L1dis
%        reali1=[ax1(1) ay1(1) az1(1)];
%    else
%        reali1=[ax1(2) ay1(2) az1(2)];
%    end
%end

%toti2=(i2(1)+i2(2)+i2(3));
%totP1L2=(ax2(1)+ay2(1)+az2(1));
%totP2L2=(ax2(2)+ay2(2)+az2(2));
%alphaL2=(toti2-totP1L2)/(totP2L2-totP1L2);
%if alphaL2>=0 && alphaL2<=1
%    reali2=i2;
%else
%    P1L2dis=sqrt((i2(1)-ax2(1))^2+(i2(2)-ay2(1))^2+(i2(1)-az2(1))^2);
%    P2L2dis=sqrt((i2(1)-ax2(2))^2+(i2(2)-ay2(2))^2+(i2(1)-az2(2))^2);
%    if P1L2dis<P2L2dis
%        reali2=[ax2(1) ay2(1) az2(1)];
%    else
%        reali2=[ax2(2) ay2(2) az2(2)];
%end
%end

