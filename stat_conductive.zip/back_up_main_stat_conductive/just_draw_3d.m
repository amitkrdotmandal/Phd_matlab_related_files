clc; clear all;
file_name="CNT_data_for_3d.xlsx";
values_modified=xlsread(file_name);
size_values=size(values_modified);


for i=1:size_values(1)
    ax=values_modified(i,1:2);
    ay=values_modified(i,3:4);
    az=values_modified(i,5:6);
    plot3(ax,ay,az,'m');
    hold on;
    pause(.0005)
end
clear values_modified;




file_name="tunnel_data_for_3d.xlsx";
values_modified=xlsread(file_name);
size_values=size(values_modified);


for i=1:size_values(1)
    ax=values_modified(i,1:2);
    ay=values_modified(i,3:4);
    az=values_modified(i,5:6);
    plot3(ax,ay,az,'b');
    hold on;
    pause(.0005)
end

text(100,100,'\leftarrow 10')