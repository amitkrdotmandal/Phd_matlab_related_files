function [is_searched_perticular_node,is_voltage_present] = function_to_contributing_nodes(resistance,resistors,node_vol)

%functio
resistance;
resistors;
node_vol;
length_node_voltage=length(node_vol);
number_of_resistors=length(resistors);
is_voltage_present=false(1,length_node_voltage);
is_searched_perticular_node=false(1,length_node_voltage);
for i=1:length_node_voltage
    isnan_node=isnan(node_vol(i));
    if isnan_node==0
        is_voltage_present(i)=1;
    end
end

is_voltage_present;
allow_search_operation=true;

while allow_search_operation==1
    for i=1:length_node_voltage
        if is_voltage_present(i)==1 && is_searched_perticular_node(i)==0
            node_to_search=i;
            is_searched_perticular_node(node_to_search)=1;
            allow_search_operation=1;
            break
        else
            allow_search_operation=0;
        end
    end
    
    if allow_search_operation==1
        for i=1:number_of_resistors
            if resistors(i,1)==node_to_search || resistors(i,2)==node_to_search
                
                if resistors(i,1)==node_to_search
                    is_voltage_present(resistors(i,2))=1;
                end
                
                if resistors(i,2)==node_to_search
                    is_voltage_present(resistors(i,1))=1;
                end
            end
        end
    end
    
end


is_searched_perticular_node;
is_voltage_present;
end