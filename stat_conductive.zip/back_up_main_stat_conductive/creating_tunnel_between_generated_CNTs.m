clc; clear all;


delete_=1
cutoff=40;
if delete_==1
    
    
    if exist('tunnel_data_for_3d.xlsx', 'file')==2
         delete('tunnel_data_for_3d.xlsx');
    end
    
    if exist('resistors_for_CNTs.xlsx', 'file')==2
         delete('resistors_for_CNTs.xlsx');
    end
    
     if exist('resistors_for_tunnels.xlsx', 'file')==2
         delete('resistors_for_tunnels.xlsx');
    end
end






file_name="CNT_data_for_3d.xlsx";
values=xlsread(file_name);
size_values=size(values);






k=1;
for i=1:size_values(1)
ax1=values(i,1:2);
ay1=values(i,3:4);
az1=values(i,5:6);
for j=i+1:size_values(1)
    
    ax2=values(j,1:2);
    ay2=values(j,3:4);
    az2=values(j,5:6);
    
    [plotx,ploty,plotz,length_,in_range] = length_det_function_modification(ax1,ay1,az1,ax2,ay2,az2,cutoff);
    
    if in_range==1
        to_save(k,1:2)=plotx;
        to_save(k,3:4)=ploty;
        to_save(k,5:6)=plotz;
        to_save(k,7)=length_;
        to_save(k,8)=i;
        to_save(k,9)=j;
        k=k+1;
    end
    
    
end
end

filename="tunnel_data_for_3d.xlsx";
xlswrite(filename,to_save)
