function [act_node_vol] = KCL_function(resistors,resistance,node_vol)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% Can handle accurate parallel resistors
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%











%resistors=[1 2;2 3;3 4;1 5;5 6;6 4;3 7];
%resistance=[1 1 1 1 1 1 1];
%node_vol=[3 NaN NaN 0 NaN NaN NaN];

%resistors=[1 2;2 3;3 4;1 5;5 6;6 4;1 7;7 4];
%resistance=[1 1 1 1 1 1 2 1];
%node_vol=[4 NaN NaN 1 NaN NaN NaN];

%resistors=[1 2;2 3;3 4;1 5;5 6;6 4;1 7;7 4;8 9;9 10];
%resistance=[1 1 1 1 1 1 2 1 4 4];                           %done
%node_vol=[4 NaN NaN 1 NaN NaN NaN 4 NaN NaN];

%resistors=[1 2;2 3;1 4;2 4;4 3];
%resistance=[5 10 51 100 10];         %done
%node_vol=[10 NaN 0 NaN];

%resistors=[1 2;2 3;2 3;1 4;4 3;4 3;3 5;5 6;5 6;3 7;3 7;7 6];
%resistance=[4 8 8 4 8 8 4 8 8 8 8 4];      %done
%node_vol=[20 NaN 10 NaN NaN 0 NaN];

%resistors=[1 2;2 3;2 3;1 4;4 3;4 3;3 5;5 6;5 6;3 7;7 6; 7 6];
%resistance=[4 8 8 4 8 8 4 8 8 4 8 8];    %done
%node_vol=[20 NaN NaN NaN  NaN 0 NaN];

%resistors=[1 2;1 4;2 3;1 3;4 2];
%resistance=[8 8 4 4 .00000001];   %done
%node_vol=[10 NaN 0 NaN];

%resistors=[1 2;2 3;2 3;1 4;1 5;4 3;5 4];   %done
%resistance=[4 8 8 8 8 4 .000001];
%node_vol=[10 NaN 0 NaN NaN];

%resistors=[1 2;2 3;2 3;1 4;1 4;4 3];
%resistance=[4 8 8 8 8 4];                     %done
%node_vol=[10 NaN 0 NaN];

%resistors=[1 2;2 3;1 3;3 4;4 5;3 5];    %done
%resistance=[8 8 3 8 8 3];
%node_vol=[0 NaN 10 NaN 0];


%resistors=[1 2;2 3;3 4]; %done
%resistance=[1 1 1 ];
%node_vol=[4 NaN 0 NaN];


size_resistor=size(resistance);
Num_nodes=size(node_vol);
nodeNum=Num_nodes(2);

act_node_mat=zeros(nodeNum);
total_sol_req=0;
for i=1:nodeNum
    vol_Y_N=isnan(node_vol(i));
    if vol_Y_N==1
        nnan(i)=1;
        clear connected
        
        for j=1:size_resistor(2)
            if resistors(j,1)==i ||resistors(j,2)==i
                if resistors(j,1)==i
                    connected(j)=resistors(j,2);
                else
                    connected(j)=resistors(j,1);
                end
                



            else
                connected(j)=0;
            end

        end
        connected;
        node_mat=zeros(1,nodeNum);
        node_mat=zeros(1,max(max(resistors)));
        inv_sum=0;
        for k=1:size_resistor(2)
            if connected(k)~=0
                inv_sum=inv_sum+1/resistance(k);
                node_mat(connected(k))=node_mat(connected(k))+1/resistance(k);


            end

        end
        node_mat(i)=-inv_sum;
        act_node_mat(i,:)=node_mat;
        total_sol_req=total_sol_req+1;




    end
end
act_node_mat;

redu_act_node_mat=zeros(total_sol_req);
redu_act_node_mat_vol=zeros(total_sol_req,1);
k=0;
for i=1:nodeNum
    vol_Y_N_i=isnan(node_vol(i));
    if vol_Y_N_i==1
    k=k+1;
    l=0;

    for j=1:nodeNum
        vol_Y_N_j=isnan(node_vol(j));
        if vol_Y_N_j==1
        l=l+1;
        redu_act_node_mat(k,l)=act_node_mat(i,j);
        else
        redu_act_node_mat_vol(k,1)=redu_act_node_mat_vol(k,1)-act_node_mat(i,j)*node_vol(j);
        end
    end
    
    end
end
redu_act_node_mat;
redu_act_node_mat_vol;
redu_vol=inv(redu_act_node_mat)*redu_act_node_mat_vol;
act_node_vol=node_vol;
l=1;
for j=1:nodeNum
        vol_Y_N_j=isnan(node_vol(j));
        if vol_Y_N_j==1
            act_node_vol(j)=redu_vol(l);
            l=l+1;
        end
end
act_node_vol;
end