first-> generate_random_CNTs
second-> creating_tunnel_between_generated_CNTs (Change cut_off)
thrid-> just_draw_3d (to visualize tunnels)
fourth-> node_making_between_CNTs_and_tunnel
fifth-> calculation_node_voltage



during_strain_calculation

first-> generate_random_CNTs
second->after_generation_of_random_CNTs_relocate_CNTs_durring_STRAIN file has to be run for different strains and "next steps has to be performed repeatedly for all stain"
thrid-> creating_tunnel_between_generated_CNTs (Change cut_off)
fourth-> just_draw_3d (to visualize tunnels)
fifth-> node_making_between_CNTs_and_tunnel
sixth-> calculation_node_voltage
