clc; clear all;



for frameno=1:196
string_file="E:\Film_experiment\biaxial_strain_image_processing\calibration\New_images3\demo_"+int2str(frameno)+".jpg";
IssC=imread(string_file);
%imtool(IssC)
x2=288;
x1=303;
y2=558;
y1=346;
angle=-atand((x2-x1)/(y2-y1));
rotated= imrotate(IssC,angle);
imshow(rotated) 
strng_image="E:\Film_experiment\biaxial_strain_image_processing\calibration\New_images3_rotated/demo_"+int2str(frameno)+".jpg"
imwrite(rotated,strng_image)
end