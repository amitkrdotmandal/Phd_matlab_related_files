clc; clear all;
v = VideoReader('5%_biaxial_sample_3.mp4');

fileIDcx = fopen('cx.txt','r');
formatSpec = '%66f';
cx = fscanf(fileIDcx,formatSpec)
fclose(fileIDcx);

fileIDcy = fopen('cy.txt','r');
formatSpec = '%66f';
cy = fscanf(fileIDcy,formatSpec)
fclose(fileIDcy);


CONSTANT=100;
ss=[9 6];




try
    k_new=1;
    for k=1:10:4000
        k
        
        I = read(v,k);
        frames=I(158:1094,:,:);      %%%%%%%%%%%%%%here may need to change according to calibrationSquare
       for i=-CONSTANT:ss(1)*CONSTANT+1
            for j=-CONSTANT:ss(2)*CONSTANT+1
                dragx= round(cx(1) +cx(2)*(j-1)+cx(3)*(i-1)+ cx(4)*(j-1)^2+cx(5)*(j-1)*(i-1)+cx(6)*(i-1)^2+cx(7)*(j-1)^3+cx(8)*(j-1)^2*(i-1)+cx(9)*(j-1)*(i-1)^2+cx(10)*(i-1)^3);
                dragy= round(cy(1) +cy(2)*(j-1)+cy(3)*(i-1)+ cy(4)*(j-1)^2+cy(5)*(j-1)*(i-1)+cy(6)*(i-1)^2+cy(7)*(j-1)^3+cy(8)*(j-1)^2*(i-1)+cy(9)*(j-1)*(i-1)^2+cy(10)*(i-1)^3);
                %iimage(i+1+CONSTANT,j+1+CONSTANT)=frames(dragy,dragx);
                if frames(dragy,dragx,2)>frames(dragy,dragx,1)+10 && frames(dragy,dragx,2)>frames(dragy,dragx,3)+5
                    iimage(i+1+CONSTANT,j+1+CONSTANT)=0;
                else
                    iimage(i+1+CONSTANT,j+1+CONSTANT)=round((frames(dragy,dragx,1)+frames(dragy,dragx,2)+frames(dragy,dragx,3))/3);
                end
       
       %COMX=roun
            end
         end
   
    
    
    imshow(iimage)
    strng_image="New_images3/demo_"+int2str(k_new)+".jpg"
    imwrite(iimage,strng_image)
     k_new=k_new+1;
    end
catch
    j=10

end
i=5


