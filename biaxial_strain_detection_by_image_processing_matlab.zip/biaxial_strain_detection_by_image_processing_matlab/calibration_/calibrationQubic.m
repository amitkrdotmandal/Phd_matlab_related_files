clc; clear all;
I=imread("Barchart.jpg");
%imtool(I)
[imagePoints,boardSize] = detectCheckerboardPoints(I);
J = insertText(I,imagePoints,1:size(imagePoints,1));
J = insertMarker(J,imagePoints,'o','Color','red','Size',5);
imtool(J);
title(sprintf('Detected a %d x %d Checkerboard',boardSize));

k=1;
row=6;
column=9;
CONSTANT=100;
for i=1:column
    for j=1:row
        pointmat(i,j,1)=imagePoints(k,1);
        pointmat(i,j,2)=imagePoints(k,2);
        imageX(k)=imagePoints(k,1);
        imageY(k)=imagePoints(k,2);
        realx(k)=CONSTANT*(j-1);
        realy(k)=CONSTANT*(i-1);
        realx2d(i,j)=CONSTANT*(j-1);
        realy2d(i,j)=CONSTANT*(i-1);

        k=k+1;
    end
end
pointmat
realy2d

myfittypeX = fittype('a1 +a2*realx+a3*realy+ a4*realx^2+a5*realx*realy+a6*realy^2',...
    'dependent',{'imageX'},'independent',{'realx','realy'},...
    'coefficients',{'a1','a2','a3','a4','a5','a6'})
myfitX = fit([realx',realy'],imageX',myfittypeX)

myfittypeY = fittype('a1 +a2*realx+a3*realy+ a4*realx^2+a5*realx*realy+a6*realy^2',...
    'dependent',{'imageY'},'independent',{'realx','realy'},...
    'coefficients',{'a1','a2','a3','a4','a5','a6'})
myfitY = fit([realx',realy'],imageY',myfittypeY)


cx=coeffvalues(myfitX)
cy=coeffvalues(myfitY)
ss=size(realy2d);
for i=-CONSTANT:ss(1)*CONSTANT+1
    for j=-CONSTANT:ss(2)*CONSTANT+1
       dragx= round(cx(1) +cx(2)*(j-1)+cx(3)*(i-1)+ cx(4)*(j-1)^2+cx(5)*(j-1)*(i-1)+cx(6)*(i-1)^2);
       dragy= round(cy(1) +cy(2)*(j-1)+cy(3)*(i-1)+ cy(4)*(j-1)^2+cy(5)*(j-1)*(i-1)+cy(6)*(i-1)^2);
       iimage(i+1+CONSTANT,j+1+CONSTANT)=I(dragy,dragx);
       
       %COMX=roun
    end
end
imtool(iimage);

i
j
