1.extraction
2.CalibrationValidation
3.CalibrationSquare
4.CalibrationValidation
5.first_calibration_image_extraction
6.if necessary rotation_image
7."New_images3_rotated" folder needs to be trnsfered to point_detection folder
