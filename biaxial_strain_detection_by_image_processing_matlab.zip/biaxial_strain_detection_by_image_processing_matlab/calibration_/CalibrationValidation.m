clc; clear all;
I=imread("generated_3.bmp");  %%%%here I need to reverse
%Iss=imread("Barchart.jpg");  %%%%here I need to reverse
%I=Iss(158:1094,:,:);         %%%%here I need to reverse
imtool(I)
[imagePoints,boardSize] = detectCheckerboardPoints(I);
J = insertText(I,imagePoints,1:size(imagePoints,1));
J = insertMarker(J,imagePoints,'o','Color','red','Size',5);
imtool(J);
title(sprintf('Detected a %d x %d Checkerboard',boardSize));

k=1;
for i=1:9
    for j=1:6
        pointmat(i,j,1)=imagePoints(k,1);
        pointmat(i,j,2)=imagePoints(k,2);
        k=k+1;
    end
end
pointmat
totaldist=0;
for i=1:9
    for j=1:5
        distX(i,j)=sqrt((pointmat(i,j,1)-pointmat(i,j+1,1))^2+(pointmat(i,j,2)-pointmat(i,j+1,2))^2);
        totaldist=totaldist+distX(i,j);
    end
end
distX
for j=1:6
    for i=1:8
        distY(i,j)=sqrt((pointmat(i,j,1)-pointmat(i+1,j,1))^2+(pointmat(i,j,2)-pointmat(i+1,j,2))^2);
        totaldist=totaldist+distY(i,j);
    end
end
distY
avedist=totaldist/(45+48)
variation=0;


for i=1:9
    for j=1:5
       variation=variation+(distX(i,j)-avedist)^2;
        
    end
end
for j=1:6
    for i=1:8
        variation=variation+(distY(i,j)-avedist)^2;
        
    end
end

stnddev=sqrt(variation/(45+48));
cofvar=stnddev/avedist*100


for i=1:8
    for j=1:5
        
        vecX=[(pointmat(i,j+1,1)-pointmat(i,j,1));(pointmat(i,j+1,2)-pointmat(i,j,2));0];
        vecY=[(pointmat(i+1,j,1)-pointmat(i,j,1));(pointmat(i+1,j,2)-pointmat(i,j,2));0];
        ANGLEE(i,j)=norm(cross(vecX,vecY))/norm(vecX)/norm(vecY);
        
    end
end
ANGLEE

m=4;

        vecX=[(pointmat(1,m,1)-pointmat(1,1,1));(pointmat(1,m,2)-pointmat(1,1,2));0];
        vecY=[(pointmat(m,1,1)-pointmat(1,1,1));(pointmat(m,1,2)-pointmat(1,1,2));0];
        ANGLE=norm(cross(vecX,vecY))/norm(vecX)/norm(vecY)
        
        
surf(pointmat(1:9,1:5,1),pointmat(1:9,1:5,2),distX)
hold on
%surf(pointmat(1:8,1:6,1),pointmat(1:8,1:6,2),distY)
