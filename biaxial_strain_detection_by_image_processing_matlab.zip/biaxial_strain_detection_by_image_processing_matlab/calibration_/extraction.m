clc; clear all;
v = VideoReader('5%_biaxial_sample_3.mp4');
I = read(v,10);

 imwrite(I,"Barchart.jpg")