function return_val=draw_color_color_map(value)
if value>255
    value=value-255;
    return_val(1)=uint8(value);
    return_val(2)=uint8(255-return_val(1));
    return_val(3)=uint8(0);
    
else
    return_val(1)=uint8(0);
    return_val(2)=uint8(value);
    return_val(3)=uint8(255-return_val(2));
end

end