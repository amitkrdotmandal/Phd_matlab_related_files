clc;clear all;

filename='points_video3.xlsx';
pos_dic_1 = xlsread(filename,1);
pos_dic_2 = xlsread(filename,2);
size_pos=size(pos_dic_1);
actual_pos_dic_1 = pos_dic_1(41:size_pos(1),:);%%%%here need to change
actual_pos_dic_2 = pos_dic_2(41:size_pos(1),:);%%%%here need to change
framess=size(actual_pos_dic_1);
no_of_frames=framess(1)/5;
for frameno=1:no_of_frames
    frame_dic_1(1:5,1:5,frameno)=actual_pos_dic_1((frameno-1)*5+1:(frameno)*5,:);
    frame_dic_2(1:5,1:5,frameno)=actual_pos_dic_2((frameno-1)*5+1:(frameno)*5,:);
end

for frameno=1:no_of_frames
    frame_displacement_dic_1(1:5,1:5,frameno)=frame_dic_1(1:5,1:5,frameno)-frame_dic_1(1:5,1:5,1);
    frame_displacement_dic_2(1:5,1:5,frameno)=frame_dic_2(1:5,1:5,frameno)-frame_dic_2(1:5,1:5,1);
end

for frameno=1:165
%frameno=125;
frame_dic_1(:,:,frameno)
k=1;
for i=1:5
    for j=1:5
        realx(k)=frame_dic_1(i,j,1);
        realy(k)=frame_dic_2(i,j,1);
        imageX(k)=frame_dic_1(i,j,frameno);
        imageY(k)=frame_dic_2(i,j,frameno);
        k=k+1;

    end
end



myfittypeX = fittype('a1 +a2*realx+a3*realy+ a4*realx^2+a5*realx*realy+a6*realy^2+a7*realx^3+a8*realx^2*realy+a9*realx*realy^2+a10*realy^3',...
    'dependent',{'imageX'},'independent',{'realx','realy'},...
    'coefficients',{'a1','a2','a3','a4','a5','a6','a7','a8','a9','a10'});
myfitX = fit([realx',realy'],imageX',myfittypeX);

myfittypeY = fittype('a1 +a2*realx+a3*realy+ a4*realx^2+a5*realx*realy+a6*realy^2+a7*realx^3+a8*realx^2*realy+a9*realx*realy^2+a10*realy^3',...
    'dependent',{'imageY'},'independent',{'realx','realy'},...
    'coefficients',{'a1','a2','a3','a4','a5','a6','a7','a8','a9','a10'});
myfitY = fit([realx',realy'],imageY',myfittypeY);


cx=coeffvalues(myfitX);
cy=coeffvalues(myfitY);
for k=1:length(realx)
    j=realx(k);
    i=realy(k);


       dragX(k)= round(cx(1) +cx(2)*(j)+cx(3)*(i)+ cx(4)*(j)^2+cx(5)*(j)*(i)+cx(6)*(i)^2+cx(7)*(j)^3+cx(8)*(j)^2*(i)+cx(9)*(j)*(i)^2+cx(10)*(i)^3);
       dragY(k)= round(cy(1) +cy(2)*(j)+cy(3)*(i)+ cy(4)*(j)^2+cy(5)*(j)*(i)+cy(6)*(i)^2+cy(7)*(j)^3+cy(8)*(j)^2*(i)+cy(9)*(j)*(i)^2+cy(10)*(i)^3);
end

max_dic1=max(max(frame_dic_1(1:5,1:5,1)));
min_dic1=min(min(frame_dic_1(1:5,1:5,1)));
max_dic2=max(max(frame_dic_2(1:5,1:5,1)));
min_dic2=min(min(frame_dic_2(1:5,1:5,1)));
exx=zeros(max_dic1,max_dic2);
eyy=zeros(max_dic1,max_dic2);
exy=zeros(max_dic1,max_dic2);
exx=exx/0;
eyy=eyy/0;
exy=exy/0;
for directionX=min_dic1:max_dic1
    for directionY=min_dic2:max_dic2
        j=directionX;
        i=directionY;
        delUdelX=(cx(2)*(1)+ 2*cx(4)*(j)^1+cx(5)*(1)*(i)+3*cx(7)*(j)^2+2*cx(8)*(j)^1*(i)+cx(9)*(1)*(i)^2)-1;
        delUdelY=(cx(3)*(1)+cx(5)*(j)*(1)+2*cx(6)*(i)^1+cx(8)*(j)^2*(1)+2*cx(9)*(j)*(i)^1+3*cx(10)*(i)^2);
        delVdelX=(cy(2)*(1)+ 2*cy(4)*(j)^1+cy(5)*(1)*(i)+3*cy(7)*(j)^2+2*cy(8)*(j)^1*(i)+cy(9)*(1)*(i)^2);
        delVdelY=(cy(3)*(1)+cy(5)*(j)*(1)+2*cy(6)*(i)^1+cy(8)*(j)^2*(1)+2*cy(9)*(j)*(i)^1+3*cy(10)*(i)^2)-1;
        exx(directionX,directionY)=delUdelX+1/2*(delUdelX^2+delVdelX^2);
        eyy(directionX,directionY)=delVdelY+1/2*(delUdelY^2+delVdelY^2);
        exy(directionX,directionY)=1/2*(delUdelY+delVdelX+delUdelX*delUdelY+delVdelX*delVdelY);
    end
end




size_e=size(exx);
sum_exx=0;
sum_eyy=0;
sum_exy=0;
tottall=0;
for i=1:size_e(1)
    
    for j=1:size_e(2)
        ii(i,j)=i;
        jj(i,j)=j;
        is_nan=isnan(exx(i,j));
        if is_nan==0
        sum_exx=sum_exx+exx(i,j);
        sum_eyy=sum_eyy+eyy(i,j);
        sum_exy=sum_exy+exy(i,j);
        tottall=tottall+1;
        end
        
    end
        
end
frame_serial(frameno)=frameno;
average_exx(frameno)=sum_exx/tottall;
average_eyy(frameno)=sum_eyy/tottall;
average_exy(frameno)=sum_exy/tottall;




for no_strian=1:3
    if no_strian==1
        matrix_e=exx;
    elseif no_strian==2
        matrix_e=eyy;
    else
        matrix_e=exy;
    end
        

max_val=max(max(matrix_e));
min_val=min(min(matrix_e));
sizeconvo=size(matrix_e);
image_ref=imread('E:\Film_experiment\calibration\New_images3_rotated\demo_9.jpg');
string_cruurent=strcat('E:\Film_experiment\calibration\New_images3_rotated\demo_',int2str(frameno+8),'.jpg');
image_curr=imread(string_cruurent);
size_ref_image=size(image_ref);
mapped_matrix_e(:,:,1)=image_ref;
mapped_matrix_e(:,:,2)=image_ref;
mapped_matrix_e(:,:,3)=image_ref;
shift_i=221;   %%%%%needed to be added manually from point_detection coding
shift_j=149;   %%%%%needed to be added manually from point_detection coding
for i=1:sizeconvo(1)
    for j=1:sizeconvo(2)
        
        is_nan=isnan(matrix_e(i,j));
        if is_nan==0
            if matrix_e(i,j)==max_val
                max_pos_i=i+shift_i;
                max_pos_j=j+shift_j;
            end
        pass_value=(round(510-510*(max_val-matrix_e(i,j))/(max_val-min_val)));
        fetch_value=draw_color_color_map(pass_value);
        fraction=.6;
        mapped_matrix_e(i+shift_i,j+shift_j,1)=uint8(round((1-fraction)*mapped_matrix_e(i+shift_i,j+shift_j,1)+(fraction)*fetch_value(1)));
        mapped_matrix_e(i+shift_i,j+shift_j,2)=uint8(round((1-fraction)*mapped_matrix_e(i+shift_i,j+shift_j,1)+(fraction)*fetch_value(2)));
        mapped_matrix_e(i+shift_i,j+shift_j,3)=uint8(round((1-fraction)*mapped_matrix_e(i+shift_i,j+shift_j,1)+(fraction)*fetch_value(3)));
        end
                   
        
    end
end
%mapped_matrix_e = insertText(mapped_matrix_e,[max_pos_j,max_pos_i],['Max_position']);
    if no_strian==1
       assembled_mapped_matrix_e=mapped_matrix_e;
       assembled_mapped_matrix_e = insertText(assembled_mapped_matrix_e,[1,1],[frameno]);
    else
        size_assembled_mapped_matrix_e=size(assembled_mapped_matrix_e);
        assembled_mapped_matrix_e(:,size_assembled_mapped_matrix_e(2)+1:size_assembled_mapped_matrix_e(2)+size_ref_image(2),:)=mapped_matrix_e;
    end
        

end

size_assembled_mapped_matrix_e=size(assembled_mapped_matrix_e);
assembled_mapped_matrix_e(:,size_assembled_mapped_matrix_e(2)+1:size_assembled_mapped_matrix_e(2)+size_ref_image(2),1)=image_curr;
assembled_mapped_matrix_e(:,size_assembled_mapped_matrix_e(2)+1:size_assembled_mapped_matrix_e(2)+size_ref_image(2),2)=image_curr;
assembled_mapped_matrix_e(:,size_assembled_mapped_matrix_e(2)+1:size_assembled_mapped_matrix_e(2)+size_ref_image(2),3)=image_curr;
color_baar=color_bar(min_val,max_val);
size_color_bar=size(color_baar);
size_assembled_mapped_matrix_e=size(assembled_mapped_matrix_e);
assembled_mapped_matrix_e(1:size_color_bar(1),size_assembled_mapped_matrix_e(2)+1:size_assembled_mapped_matrix_e(2)+size_color_bar(2),:)=color_baar;


%surf(ii,jj,matrix_e)


imshow(assembled_mapped_matrix_e)
%filenameeee= strcat('exx_eyy_exy_165','.xlsx') ;
%xlswrite(filenameeee,exx,1)
%xlswrite(filenameeee,eyy,2)
%xlswrite(filenameeee,exy,3)
end
average_exx
plot(frame_serial,average_exx)
hold on
plot(frame_serial,average_eyy)
hold on
plot(frame_serial,average_exy)