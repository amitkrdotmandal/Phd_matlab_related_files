function RGB=color_bar(min_val,max_val)
for i=1:510
    min_position=1;
    mid_position=255;
    max_position=510;
    for j=1:50
        vval=draw_color_color_map(i);
        a(i,j,1)=vval(1);
        a(i,j,2)=vval(2);
        a(i,j,3)=vval(3);
    end
end
b(:,:,1)=uint8(255*ones(560,180));
b(:,:,2)=uint8(255*ones(560,180));
b(:,:,3)=uint8(255*ones(560,180));
b(1:510,51:100,1)=a(:,:,1);
b(1:510,51:100,2)=a(:,:,2);
b(1:510,51:100,3)=a(:,:,3);
RGB = insertText(b,[100,min_position;100,mid_position;100,max_position],[min_val,(min_val+max_val)/2,max_val]);
end