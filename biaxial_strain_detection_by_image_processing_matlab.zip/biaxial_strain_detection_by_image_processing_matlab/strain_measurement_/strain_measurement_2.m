clc;clear all;

filename='points_video3.xlsx';
pos_dic_1 = xlsread(filename,1);
pos_dic_2 = xlsread(filename,2);
size_pos=size(pos_dic_1);
actual_pos_dic_1 = pos_dic_1(41:size_pos(1),:);%%%%here need to change
actual_pos_dic_2 = pos_dic_2(41:size_pos(1),:);%%%%here need to change
framess=size(actual_pos_dic_1);
no_of_frames=framess(1)/5;
for frameno=1:no_of_frames
    frame_dic_1(1:5,1:5,frameno)=actual_pos_dic_1((frameno-1)*5+1:(frameno)*5,:);
    frame_dic_2(1:5,1:5,frameno)=actual_pos_dic_2((frameno-1)*5+1:(frameno)*5,:);
end

for frameno=1:no_of_frames
    frame_displacement_dic_1(1:5,1:5,frameno)=frame_dic_1(1:5,1:5,frameno)-frame_dic_1(1:5,1:5,1);
    frame_displacement_dic_2(1:5,1:5,frameno)=frame_dic_2(1:5,1:5,frameno)-frame_dic_2(1:5,1:5,1);
end


frameno=151;
max_dic1=max(max(frame_dic_1(1:5,1:5,1)));
min_dic1=min(min(frame_dic_1(1:5,1:5,1)));
max_dic2=max(max(frame_dic_2(1:5,1:5,1)));
min_dic2=min(min(frame_dic_2(1:5,1:5,1)));
iden_matrix=zeros(max_dic1,max_dic2);
exx=zeros(max_dic1,max_dic2);
eyy=zeros(max_dic1,max_dic2);
exy=zeros(max_dic1,max_dic2);
exx=exx/1;
eyy=eyy/1;
exy=exy/1;
for directionX=min_dic1:max_dic1
for directionY=min_dic2:max_dic2
%directionX=150;
%directionY=150;
    for eleNo=1:16
    %eleNo
    remainder=mod(eleNo,4);
    eleno_minus_remainder=(eleNo-remainder)/4;
    if remainder==0
        dic1_ele=eleno_minus_remainder;
        dic2_ele=4;        
    else
        dic1_ele=eleno_minus_remainder+1;
        dic2_ele=remainder;        
    end
    %dic1_ele
    %dic2_ele
    element_node_1(eleNo,1)=frame_dic_1(dic1_ele,dic2_ele,1);  % x direction
    element_node_1(eleNo,2)=frame_dic_1(dic1_ele,dic2_ele+1,1);  % x direction
    element_node_1(eleNo,3)=frame_dic_1(dic1_ele+1,dic2_ele+1,1);  % x direction
    element_node_1(eleNo,4)=frame_dic_1(dic1_ele+1,dic2_ele,1);    % x direction
    element_node_2(eleNo,1)=frame_dic_2(dic1_ele,dic2_ele,1);     % y direction
    element_node_2(eleNo,2)=frame_dic_2(dic1_ele,dic2_ele+1,1);   % y direction
    element_node_2(eleNo,3)=frame_dic_2(dic1_ele+1,dic2_ele+1,1);  % y direction
    element_node_2(eleNo,4)=frame_dic_2(dic1_ele+1,dic2_ele,1);    % y direction

    
    element_node_displacement_1(eleNo,1)=frame_displacement_dic_1(dic1_ele,dic2_ele,frameno);   % x direction
    element_node_displacement_1(eleNo,2)=frame_displacement_dic_1(dic1_ele,dic2_ele+1,frameno);   % x direction
    element_node_displacement_1(eleNo,3)=frame_displacement_dic_1(dic1_ele+1,dic2_ele+1,frameno); % x direction
    element_node_displacement_1(eleNo,4)=frame_displacement_dic_1(dic1_ele+1,dic2_ele,frameno);   % x direction
    element_node_displacement_2(eleNo,1)=frame_displacement_dic_2(dic1_ele,dic2_ele,frameno);    % y direction
    element_node_displacement_2(eleNo,2)=frame_displacement_dic_2(dic1_ele,dic2_ele+1,frameno);   % y direction
    element_node_displacement_2(eleNo,3)=frame_displacement_dic_2(dic1_ele+1,dic2_ele+1,frameno);    % y direction
    element_node_displacement_2(eleNo,4)=frame_displacement_dic_2(dic1_ele+1,dic2_ele,frameno);    % y direction
    
    
    
    
    x=directionX;
    y=directionY;
    %x=element_node_1(eleNo,1);
    %y=element_node_2(eleNo,1);
    if iden_matrix(x,y)==0
    
     fun2=@(rs) [(1/4*(1-rs(1))*(1-rs(2))*element_node_1(eleNo,1)+1/4*(1+rs(1))*(1-rs(2))*element_node_1(eleNo,2)+1/4*(1+rs(1))*(1+rs(2))*element_node_1(eleNo,3)+1/4*(1-rs(1))*(1+rs(2))*element_node_1(eleNo,4)-x);
        (1/4*(1-rs(1))*(1-rs(2))*element_node_2(eleNo,1)+1/4*(1+rs(1))*(1-rs(2))*element_node_2(eleNo,2)+1/4*(1+rs(1))*(1+rs(2))*element_node_2(eleNo,3)+1/4*(1-rs(1))*(1+rs(2))*element_node_2(eleNo,4)-y)];
    rrss=fsolve(fun2,[1,1]);
    
    rr(eleNo)=rrss(1);
    ss(eleNo)=rrss(2);
    
    
    r=rr(eleNo);
    s=rr(eleNo);
    if r<=1 && r>=-1 && s<=1 && s>=-1
    iden_matrix(x,y)=1;
    
    N=[1/4*(1-r)*(1-s) 1/4*(1+r)*(1-s) 1/4*(1+r)*(1+s) 1/4*(1-r)*(1+s)];
    DNr =[-(1-s)/4,(1-s)/4,(1+s)/4,-(1+s)/4];
    DNs = [-(1-r)/4,-(1+r)/4,(1+r)/4,(1-r)/4];
    
    Xpoints=[element_node_1(eleNo,1) element_node_1(eleNo,2) element_node_1(eleNo,3) element_node_1(eleNo,4)];
    Ypoints=[element_node_2(eleNo,1) element_node_2(eleNo,2) element_node_2(eleNo,3) element_node_2(eleNo,4)];
    Upoints=[element_node_displacement_1(eleNo,1) element_node_displacement_1(eleNo,2) element_node_displacement_1(eleNo,3) element_node_displacement_1(eleNo,4)];
    Vpoints=[element_node_displacement_2(eleNo,1) element_node_displacement_2(eleNo,2) element_node_displacement_2(eleNo,3) element_node_displacement_2(eleNo,4)];
   
    X(eleNo)=N*Xpoints';
    Y(eleNo)=N*Ypoints';  
    U(eleNo)=N*Upoints';
    V(eleNo)=N*Vpoints';
    
    delXdelr=DNr*Xpoints';
    delXdels=DNs*Xpoints';
    delYdelr=DNr*Ypoints';
    delYdels=DNs*Ypoints';
    Jmatrix=[delXdelr delYdelr;delXdels delYdels];
    Jstarmatrix=inv(Jmatrix);
    
    delUdelr=DNr*Upoints';
    delUdels=DNs*Upoints';
    delVdelr=DNr*Vpoints';
    delVdels=DNs*Vpoints';
    
    delUdelXdelUdelY=Jstarmatrix*[delUdelr delUdels]';
    delVdelXdelVdelY=Jstarmatrix*[delVdelr delVdels]';
    
    
    exx(x,y)=delUdelXdelUdelY(1)+1/2*((delUdelXdelUdelY(1))^2+(delVdelXdelVdelY(1))^2);
    eyy(x,y)=delVdelXdelVdelY(2)+1/2*((delUdelXdelUdelY(2))^2+(delVdelXdelVdelY(2))^2);
    exy(x,y)=1/2*(delUdelXdelUdelY(2)+delVdelXdelVdelY(1)+delUdelXdelUdelY(1)*delUdelXdelUdelY(2)+delVdelXdelVdelY(1)*delVdelXdelVdelY(2));
    

        
    end
    
        
    end
    
    
    
   
    

    


end
end
end

element_node_1
element_node_2;
exx(x,y)
filenameeee= strcat('exx_eyy_exy_151','.xlsx') ;
xlswrite(filenameeee,exx,1)
xlswrite(filenameeee,eyy,2)
xlswrite(filenameeee,exy,3)