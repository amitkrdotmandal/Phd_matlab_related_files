clc;
clear all;
IssR=imread("E:\Film_experiment\calibration\New_images3\demo_18.jpg");
ssize=size(IssR);
for i=1:ssize(1)
    for j=1:ssize(2)
        if IssR(i,j)<50
            modIssR(i,j)=IssR(i,j);
        else
            modIssR(i,j)=IssR(i,j);
        end
    end
end

%imtool(modIssR)
%imtool(IssR)





for frameno=9:173
searchin=[121.25 199.25 460.5 403.5];   %%%%here need to change

string_file="E:\Film_experiment\calibration\New_images3\demo_"+int2str(frameno)+".jpg";
IssC=imread(string_file);
ssizeC=size(IssC);
for i=1:ssizeC(1)
    for j=1:ssizeC(2)
        if IssC(i,j)<70
            modIssC(i,j)=0;
        else
            modIssC(i,j)=255;
        end
    end
end
searchwindow=modIssC(round(searchin(2)):round(searchin(2)+searchin(4)),round(searchin(1)):round(searchin(1)+searchin(3)));
%imtool(modIssC)
%imtool(searchwindow)
sss=(size(searchwindow));
vval=zeros(sss(1),sss(2));


searchfor(:,1)=[270.5 472.5 63 68];
window=modIssC(round(searchfor(2)):round(searchfor(2,1)+searchfor(4,1)),round(searchfor(1,1)):round(searchfor(1,1)+searchfor(3,1)));
%imtool(window)
sizewin=size(searchwindow);





%%%%%%%%%%%dtection in weft direction
for i=1:sss(1)
    dic1(i)=i;
    first_dic(i)=0;
    for j=1:sss(2)
        first_dic(i)=first_dic(i)+searchwindow(i,j);
    end
end
%plot(dic1,first_dic)
hold on
first_dic_smooth=smoothdata(first_dic,'gaussian',40);
%plot(dic1,first_dic_smooth)
movi_avg_step=40;
first_dic=movingaverage(first_dic_smooth,movi_avg_step);
%plot(dic1,first_dic)
reversed_first_dic_smooth=datareverse(first_dic_smooth);
reversed_first_dic=movingaverage(reversed_first_dic_smooth,movi_avg_step);
reversed_first_dic=datareverse(reversed_first_dic);
%plot(dic1,reversed_first_dic)
k=1;
start_detecting_first=0;
for i=1:sss(1)
    if i<sss(1)-1
    if start_detecting_first==0
        if (first_dic_smooth(i+2)-first_dic_smooth(i))/2>400
            start_detecting_first=1;
        end
    end
    if start_detecting_first==1
    
        if first_dic(i)>first_dic_smooth(i)
            if first_dic(i+1)==first_dic_smooth(i+1)||first_dic(i+1)<first_dic_smooth(i+1)
                first_left_intersect(k)=i;
                k=k+1;
            end
        end
    end
    end
end
k=1;
start_detecting_first=0;
for i=1:sss(1)
    if i<sss(1)-1
        if start_detecting_first==0
            if (first_dic_smooth(i+2)-first_dic_smooth(i))/2>400
                start_detecting_first=1;
            end
        end
        if start_detecting_first==1
        if reversed_first_dic(i)<first_dic_smooth(i)
            if reversed_first_dic(i+1)==first_dic_smooth(i+1)||reversed_first_dic(i+1)>first_dic_smooth(i+1)
                first_right_intersect(k)=i;
                k=k+1;
            end
        end
        end
    end
end
for i=1:5
    first_intersect(i)=round((first_left_intersect(i)+first_right_intersect(i))/2);
end
detect_lines=searchwindow;
for i=1:5
    for j=1:sss(2)
        detect_lines(first_intersect(i)-1,j)=125;
        detect_lines(first_intersect(i),j)=125;
        detect_lines(first_intersect(i)+1,j)=125;
    end
end
average_distance_first_direction=0;
for i=1:4
    average_distance_first_direction=average_distance_first_direction+first_intersect(i+1)-first_intersect(i);
end
average_distance_first_direction=round(average_distance_first_direction/4);



%%%%%%%%%%%dtection in warp direction
for i=1:sss(2)
    second_dic(i)=0;
    for j=1:sss(1)
        second_dic(i)=second_dic(i)+searchwindow(j,i);
    end
end
%plot(dic1,first_dic)
hold on
second_dic_smooth=smoothdata(second_dic,'gaussian',40);
%plot(dic1,first_dic_smooth)
movi_avg_step=40;
second_dic=movingaverage(second_dic_smooth,movi_avg_step);
%plot(dic1,first_dic)
reversed_second_dic_smooth=datareverse(second_dic_smooth);
reversed_second_dic=movingaverage(reversed_second_dic_smooth,movi_avg_step);
reversed_second_dic=datareverse(reversed_second_dic);
%plot(dic1,reversed_first_dic)
k=1;
start_detecting_second=0;
for i=1:sss(2)
    if i<sss(2)-1
    if start_detecting_second==0
        if (second_dic_smooth(i+2)-second_dic_smooth(i))/2>400
            start_detecting_second=1;
        end
    end
    if start_detecting_second==1
    
        if second_dic(i)>second_dic_smooth(i)
            if second_dic(i+1)==second_dic_smooth(i+1)||second_dic(i+1)<second_dic_smooth(i+1)
                second_left_intersect(k)=i;
                k=k+1;
            end
        end
    end
    end
end
k=1;
start_detecting_second=0;
for i=1:sss(2)
    if i<sss(2)-1
        if start_detecting_second==0
            if (second_dic_smooth(i+2)-second_dic_smooth(i))/2>400
                start_detecting_second=1;
            end
        end
        if start_detecting_second==1
        if reversed_second_dic(i)<second_dic_smooth(i)
            if reversed_second_dic(i+1)==second_dic_smooth(i+1)||reversed_second_dic(i+1)>second_dic_smooth(i+1)
                second_right_intersect(k)=i;
                k=k+1;
            end
        end
        end
    end
end
for i=1:5
    second_intersect(i)=round((second_left_intersect(i)+second_right_intersect(i))/2);
end
for i=1:5
    for j=1:sss(1)
        detect_lines(j,second_intersect(i)-1)=125;
        detect_lines(j,second_intersect(i))=125;
        detect_lines(j,second_intersect(i)+1)=125;
    end
end
average_distance_second_direction=0;
for i=1:4
    average_distance_second_direction=average_distance_second_direction+second_intersect(i+1)-second_intersect(i);
end
average_distance_second_direction=round(average_distance_second_direction/4);
%imshow(detect_lines)





modified_matrix=zeros(sss(1),sss(2),'uint8');
for i=1:5
    first_dic_cell_start_point=round(first_intersect(1)+(i-1)*average_distance_first_direction-average_distance_first_direction/2);
    first_dic_cell_end_point=round(first_intersect(1)+(i-1)*average_distance_first_direction+average_distance_first_direction/2-1);
    for j=1:5
        second_dic_cell_start_point=round(second_intersect(1)+(j-1)*average_distance_second_direction-average_distance_second_direction/2);
        second_dic_cell_end_point=round(second_intersect(1)+(j-1)*average_distance_second_direction+average_distance_second_direction/2-1);
        clear celll;
        celll=searchwindow(first_dic_cell_start_point:first_dic_cell_end_point,second_dic_cell_start_point:second_dic_cell_end_point);
        for k=1:1
            %size_cell=size(celll);
            %reduced_window=window(1:size_cell(1),1:size_cell(2));
            celll=(conv2(celll,window,'same'));
            celll=maap(celll);
            cell=celll;
            
        end
        for k=1:20
            celll=multiplyele2ele(celll,celll);
            celll=maap(celll);
        end
        modified_matrix(first_dic_cell_start_point:first_dic_cell_end_point,second_dic_cell_start_point:second_dic_cell_end_point,1)=cell;
        modified_matrix(first_dic_cell_start_point:first_dic_cell_end_point,second_dic_cell_start_point:second_dic_cell_end_point,2)=cell;
        modified_matrix(first_dic_cell_start_point:first_dic_cell_end_point,second_dic_cell_start_point:second_dic_cell_end_point,3)=cell;
        modified_matrix(first_dic_cell_start_point:first_dic_cell_end_point,second_dic_cell_start_point:second_dic_cell_end_point,2)=celll;
        
    end
end
imshow(modified_matrix)

pause(.5)

end
imtool(searchwindow)
