function Ab=maap(A)

max_val=max(max(A));
min_val=min(min(A));
sizeconvo=size(A);
for i=1:sizeconvo(1)
    for j=1:sizeconvo(2)
        
        ff=255/double(max_val-min_val);
        hh= round((A(i,j))*ff);
        Ab(i,j)=uint8(hh);
        %vval(i,j,2)=round(convoluted(i,j)*255/(max_val-min_val));
        %vval(i,j,3)=round(convoluted(i,j)*255/(max_val-min_val));
        
        
    end
end

end