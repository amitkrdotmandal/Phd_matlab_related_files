function modmat=movingaverage(mat,step)

size_mat=size(mat);
for i=1:size_mat(2)-step+1
    modmat(i)=0;
    for j=1:step
        modmat(i)=modmat(i)+mat(i-1+j);
    end
    modmat(i)=modmat(i)/step;
end

for i=size_mat(2)-step+2:size_mat(2)
     modmat(i)=mat(i);
end

end