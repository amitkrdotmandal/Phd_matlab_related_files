function Ab=multiplyele2ele(A,B)
sizeconvo=size(A);
for i=1:sizeconvo(1)
    for j=1:sizeconvo(2)
        
        Ab(i,j)= uint16(A(i,j))*uint16(B(i,j));
        %vval(i,j,2)=round(convoluted(i,j)*255/(max_val-min_val));
        %vval(i,j,3)=round(convoluted(i,j)*255/(max_val-min_val));
        
        
    end
end


end