clc;
clear all;
IssR=imread("E:\Film_experiment\calibration\New_images3\demo_18.jpg");
ssize=size(IssR);
for i=1:ssize(1)
    for j=1:ssize(2)
        if IssR(i,j)<50
            modIssR(i,j)=IssR(i,j);
        else
            modIssR(i,j)=IssR(i,j);
        end
    end
end

imtool(modIssR)
%imtool(IssR)





for frameno=8:170
searchin=[200 240 421.5 426];   %%%%here need to change

string_file="E:\Film_experiment\calibration\New_images3\demo_"+int2str(frameno)+".jpg";
IssC=imread(string_file);
ssizeC=size(IssC);
for i=1:ssizeC(1)
    for j=1:ssizeC(2)
        if IssC(i,j)<55
            modIssC(i,j)=0;
        else
            modIssC(i,j)=255;
        end
    end
end
searchwindow=modIssC(round(searchin(2)):round(searchin(2)+searchin(4)),round(searchin(1)):round(searchin(1)+searchin(3)));
%imtool(modIssC)
%imtool(searchwindow)
sss=(size(searchwindow));
vval=zeros(sss(1),sss(2));




searchfor(:,2)=[270.5 472.5 63 68];
searchfor(:,1)=[270.5 472.5 63 68];

for Is=1:1
%searchfor=[250.25 262.25 226.5 234];
clear window;
window=modIssC(round(searchfor(2)):round(searchfor(2,Is)+searchfor(4,Is)),round(searchfor(1,Is)):round(searchfor(1,Is)+searchfor(3,Is)));
%imtool(window)
sizewin=size(searchwindow);




%convoluted=(conv2(searchwindow,window,'same'));
for i=1:sizewin(1)
    for j=1:sizewin(2)
        voluted(i,j)=searchwindow(i,j);
    end
end


sizeconvo=size(voluted);

for i=1:sizeconvo(1)
    for j=1:sizeconvo(2)
        vval(i,j)= vval(i,j)+voluted(i,j);
       % vval(i,j)= uint8(round(convoluted(i,j)*255/(max_val-min_val)));
        %vval(i,j,2)=round(convoluted(i,j)*255/(max_val-min_val));
        %vval(i,j,3)=round(convoluted(i,j)*255/(max_val-min_val));
        
        
    end
end
end


%histogram(vval)



%vvall=(conv2(vval,multiplyele2ele(window,window),'same'));
vvall=(conv2(vval,window,'same'));
%vvall=(conv2(vvall,window,'same'));
%vvall=vval;
size(vvall)
max_val=max(max(vvall));
min_val=min(min(vvall));
for i=1:sizeconvo(1)
    for j=1:sizeconvo(2)
        
        vvval(i,j)= uint8(round(vvall(i,j)*255/(max_val-min_val)));
        %vval(i,j,2)=round(convoluted(i,j)*255/(max_val-min_val));
        %vval(i,j,3)=round(convoluted(i,j)*255/(max_val-min_val));
        
        
    end
end

%imtool(vvval)

for i=1:3 %%%%here need to change
vvval2=multiplyele2ele(vvval,vvval);
vvval2=maap(vvval2);
vvval=vvval2;
end
vvval2=multiplyele2ele(vvval,vvval);
vvval2=maap(vvval2);






tolen=60;           %%%%here need to change
width=8;
black=(zeros(tolen));
neethorizon=(255*ones(width,tolen));
whiteneethorizon=black;
whiteneethorizon(round(tolen/2-width/2+1):round(tolen/2+width/2),:)=neethorizon;
neetvertical=(255*ones(tolen,width));
whiteneetvertical=black;
whiteneetvertical(:,round(tolen/2-width/2+1):round(tolen/2+width/2))=neetvertical;
whiteneetverticalhorizon=whiteneetvertical;
whiteneetverticalhorizon(round(tolen/2-width/2+1):round(tolen/2+width/2),:)=neethorizon;
jjj=0;
emni=black;
emni(round(tolen/2-width/2+1+jjj):round(tolen/2+width/2+jjj),:)=neethorizon;
purewhite=(255*ones(tolen,tolen));
%dekhi=(conv2(whiteneetverticalhorizon,neetvertical,'same'));
dekhi=multiplyele2ele(emni,whiteneethorizon);

dekhi=maap(dekhi);
dekhi(20,30)
%imtool(dekhi)


 
%vvvalll=vvval2;
for k=1:tolen*1:sizeconvo(1)-tolen           %%%%here I DONT need to change
for m=1:tolen*1:sizeconvo(2)-tolen
kk=k+tolen/2;
mm=m+tolen/2;
%clear lllast
for i=kk-tolen/2:kk+tolen/2-1
    for j=mm-tolen/2:mm+tolen/2-1
        %vvval(i,j)=125;
        lllast(i-k+1,j-m+1)=vvval2(i,j); %%%%here need to change
    end
end
if max(max(lllast))>5    %%%%here need to change
lllast=multiplyele2ele(lllast,lllast);
lllast=maap(lllast);
lllast=multiplyele2ele(lllast,lllast);
lllast=maap(lllast);
lllast=multiplyele2ele(lllast,lllast);
lllast=maap(lllast);
lllast=multiplyele2ele(lllast,lllast);
lllast=maap(lllast);
lllast=multiplyele2ele(lllast,lllast);
lllast=maap(lllast);
for i=kk-tolen/2:kk+tolen/2-1
    for j=mm-tolen/2:mm+tolen/2-1
        %vvval(i,j)=125;
        vvvalll(i,j)=uint8(lllast(i-k+1,j-m+1));
    end
end
%vvval(k:k+tolen-1,m:m++tolen-1)=uint8(lllast);
else
    for i=kk-tolen/2:kk+tolen/2-1
    for j=mm-tolen/2:mm+tolen/2-1
        %vvval(i,j)=125;
        vvvalll(i,j)=uint8(0);
    end
end
    
end
%histogram(lllast)
%imshow(lllast)


end
end
imshow(vvvalll)


pause(.05)








end
imtool(vvval2)