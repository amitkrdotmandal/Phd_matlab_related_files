function reversed_data=datareverse(data)
size_data=size(data);
j=1;
for i=size_data(2):-1:1
    reversed_data(j)=data(i);
    j=j+1;
end

end