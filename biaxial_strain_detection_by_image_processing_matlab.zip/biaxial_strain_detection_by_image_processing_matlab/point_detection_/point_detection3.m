clc;
clear all;
IssR=imread("E:\Film_experiment\calibration\New_images3\demo_18.jpg");
ssize=size(IssR);
for i=1:ssize(1)
    for j=1:ssize(2)
        if IssR(i,j)<50
            modIssR(i,j)=IssR(i,j);
        else
            modIssR(i,j)=IssR(i,j);
        end
    end
end

%imtool(modIssR)
%imtool(IssR)





for frameno=17:17
searchin=[148.25 191.75 429 354];

string_file="E:\Film_experiment\calibration\New_images3\demo_"+int2str(frameno)+".jpg";
IssC=imread(string_file);
ssizeC=size(IssC);
for i=1:ssizeC(1)
    for j=1:ssizeC(2)
        if IssC(i,j)<55
            modIssC(i,j)=0;
        else
            modIssC(i,j)=255;
        end
    end
end
searchwindow=modIssC(round(searchin(2)):round(searchin(2)+searchin(4)),round(searchin(1)):round(searchin(1)+searchin(3)));
%imtool(modIssC)
%imtool(searchwindow)
sss=(size(searchwindow));
vval=zeros(sss(1),sss(2));




searchfor(:,2)=[270.5 472.5 63 68];
searchfor(:,1)=[270.5 472.5 63 68];

for Is=1:1
%searchfor=[250.25 262.25 226.5 234];
clear window;
window=modIssC(round(searchfor(2)):round(searchfor(2,Is)+searchfor(4,Is)),round(searchfor(1,Is)):round(searchfor(1,Is)+searchfor(3,Is)));
%imtool(window)
sizewin=size(searchwindow);




%convoluted=(conv2(searchwindow,window,'same'));
for i=1:sizewin(1)
    for j=1:sizewin(2)
        voluted(i,j)=searchwindow(i,j);
    end
end


sizeconvo=size(voluted)

for i=1:sizeconvo(1)
    for j=1:sizeconvo(2)
        vval(i,j)= vval(i,j)+voluted(i,j);
       % vval(i,j)= uint8(round(convoluted(i,j)*255/(max_val-min_val)));
        %vval(i,j,2)=round(convoluted(i,j)*255/(max_val-min_val));
        %vval(i,j,3)=round(convoluted(i,j)*255/(max_val-min_val));
        
        
    end
end
end


%histogram(vval)



%vvall=(conv2(vval,multiplyele2ele(window,window),'same'));
vvall=(conv2(vval,window,'same'));
%vvall=(conv2(vvall,window,'same'));
%vvall=vval;
size(vvall)
max_val=max(max(vvall));
min_val=min(min(vvall));
for i=1:sizeconvo(1)
    for j=1:sizeconvo(2)
        
        vvval(i,j)= uint8(round(vvall(i,j)*255/(max_val-min_val)));
        %vval(i,j,2)=round(convoluted(i,j)*255/(max_val-min_val));
        %vval(i,j,3)=round(convoluted(i,j)*255/(max_val-min_val));
        
        
    end
end

%imtool(vvval)
vvval=multiplyele2ele(vvval,vvval);
vvval1=maap(vvval);

%imtool(vvval)
vvval=multiplyele2ele(vvval1,vvval1);
vvval1=maap(vvval);
imshow(vvval1)



pause(.05)
end
