clc;
clear all;
%IssR=imread("E:\Film_experiment\calibration\New_images3\demo_9.jpg");
IssR=imread("New_images3_rotated\demo_9.jpg");
%IssR=imread("E:\Film_experiment\calibration\New_images3_rotated\demo_9.jpg");
ssize=size(IssR);
for i=1:ssize(1)
    for j=1:ssize(2)
        if IssR(i,j)<70
            modIssR(i,j)=IssR(i,j);
        else
            modIssR(i,j)=IssR(i,j);
        end
    end
end

%imtool(modIssR)

IssR=multiplyele2ele(IssR,IssR);
IssR=maap(IssR);
%IssR=multiplyele2ele(IssR,IssR);
%IssR=maap(IssR);
%IssR=multiplyele2ele(IssR,IssR);
%imtool(IssR)








for frameno=9:173
searchin=[178.25 295.25 388.5 390];   %%%%here need to change
%searchin=[148.5 220.5 413 383];   %%%%here need to change
%string_file="E:\Film_experiment\calibration\New_images3\demo_"+int2str(frameno)+".jpg";
string_file="New_images3_rotated\demo_"+int2str(frameno)+".jpg";
%string_file="E:\Film_experiment\calibration\New_images3_rotated\demo_"+int2str(frameno)+".jpg";
IssC=imread(string_file);
ssizeC=size(IssC);
for i=1:ssizeC(1)
    for j=1:ssizeC(2)
        if IssC(i,j)<70
            modIssC(i,j)=0;
        else
            modIssC(i,j)=255;
        end
    end
end
searchwindow=modIssC(round(searchin(2)):round(searchin(2)+searchin(4)),round(searchin(1)):round(searchin(1)+searchin(3)));
searchwindow_real=IssC(round(searchin(2)):round(searchin(2)+searchin(4)),round(searchin(1)):round(searchin(1)+searchin(3)));
%imtool(modIssC)
%imtool(searchwindow)
sss=(size(searchwindow));
vval=zeros(sss(1),sss(2));


searchfor(:,1)=[295.5 551.5 59 62];        %%%%here need to change
%searchfor(:,1)=[293.5 489.5 54 51];
window=IssR(round(searchfor(2)):round(searchfor(2,1)+searchfor(4,1)),round(searchfor(1,1)):round(searchfor(1,1)+searchfor(3,1)));
%imtool(window)
sizewin=size(searchwindow);





%%%%%%%%%%%dtection in weft direction
for i=1:sss(1)
    dic1(i)=i;
    first_dic(i)=0;
    for j=1:sss(2)
        first_dic(i)=first_dic(i)+searchwindow(i,j);
    end
end
hold on
draw_first=0;
if draw_first==0
    
%plot(dic1,first_dic,'LineWidth',8)
draw_first=1;


first_dic_smooth=smoothdata(first_dic,'gaussian',40);
plot(dic1,first_dic_smooth,'LineWidth',8)

movi_avg_step=40;
first_dic=movingaverage(first_dic_smooth,movi_avg_step);
plot(dic1,first_dic,'LineWidth',8)
reversed_first_dic_smooth=datareverse(first_dic_smooth);
reversed_first_dic=movingaverage(reversed_first_dic_smooth,movi_avg_step);
reversed_first_dic=datareverse(reversed_first_dic);
plot(dic1,reversed_first_dic,'LineWidth',8)
end
pause 5
hold off

k=1;
start_detecting_first=0;
for i=1:sss(1)
    if i<sss(1)-1
    if start_detecting_first==0
        if (first_dic_smooth(i+2)-first_dic_smooth(i))/2>400
            start_detecting_first=1;
        end
    end
    if start_detecting_first==1
    
        if first_dic(i)>first_dic_smooth(i)
            if first_dic(i+1)==first_dic_smooth(i+1)||first_dic(i+1)<first_dic_smooth(i+1)
                first_left_intersect(k)=i;
                k=k+1;
            end
        end
    end
    end
end
k=1;
start_detecting_first=0;
for i=1:sss(1)
    if i<sss(1)-1
        if start_detecting_first==0
            if (first_dic_smooth(i+2)-first_dic_smooth(i))/2>400
                start_detecting_first=1;
            end
        end
        if start_detecting_first==1
        if reversed_first_dic(i)<first_dic_smooth(i)
            if reversed_first_dic(i+1)==first_dic_smooth(i+1)||reversed_first_dic(i+1)>first_dic_smooth(i+1)
                first_right_intersect(k)=i;
                k=k+1;
            end
        end
        end
    end
end
for i=1:5
    first_intersect(i)=round((first_left_intersect(i)+first_right_intersect(i))/2);
end
detect_lines=searchwindow;
for i=1:5
    for j=1:sss(2)
        detect_lines(first_intersect(i)-1,j)=125;
        detect_lines(first_intersect(i),j)=125;
        detect_lines(first_intersect(i)+1,j)=125;
    end
end
average_distance_first_direction=0;
for i=1:4
    average_distance_first_direction=average_distance_first_direction+first_intersect(i+1)-first_intersect(i);
    edge_points_first(i+1)= round((first_intersect(i+1)+first_intersect(i))/2);
end
average_distance_first_direction=round(average_distance_first_direction/4);
edge_points_first(1)=round(first_intersect(1)-average_distance_first_direction/2)-10;  %%%%10 emni
edge_points_first(6)=round(first_intersect(5)+average_distance_first_direction/2);




%%%%%%%%%%%dtection in warp direction
for i=1:sss(2)
    second_dic(i)=0;
    for j=1:sss(1)
        second_dic(i)=second_dic(i)+searchwindow(j,i);
    end
end
%plot(dic1,first_dic)
hold on
second_dic_smooth=smoothdata(second_dic,'gaussian',40);
%plot(dic1,first_dic_smooth)
movi_avg_step=40;
second_dic=movingaverage(second_dic_smooth,movi_avg_step);
%plot(dic1,first_dic)
reversed_second_dic_smooth=datareverse(second_dic_smooth);
reversed_second_dic=movingaverage(reversed_second_dic_smooth,movi_avg_step);
reversed_second_dic=datareverse(reversed_second_dic);
%plot(dic1,reversed_first_dic)
k=1;
start_detecting_second=0;
for i=1:sss(2)
    if i<sss(2)-1
    if start_detecting_second==0
        if (second_dic_smooth(i+2)-second_dic_smooth(i))/2>400
            start_detecting_second=1;
        end
    end
    if start_detecting_second==1
    
        if second_dic(i)>second_dic_smooth(i)
            if second_dic(i+1)==second_dic_smooth(i+1)||second_dic(i+1)<second_dic_smooth(i+1)
                second_left_intersect(k)=i;
                k=k+1;
            end
        end
    end
    end
end
k=1;
start_detecting_second=0;
for i=1:sss(2)
    if i<sss(2)-1
        if start_detecting_second==0
            if (second_dic_smooth(i+2)-second_dic_smooth(i))/2>400
                start_detecting_second=1;
            end
        end
        if start_detecting_second==1
        if reversed_second_dic(i)<second_dic_smooth(i)
            if reversed_second_dic(i+1)==second_dic_smooth(i+1)||reversed_second_dic(i+1)>second_dic_smooth(i+1)
                second_right_intersect(k)=i;
                k=k+1;
            end
        end
        end
    end
end
for i=1:5
    second_intersect(i)=round((second_left_intersect(i)+second_right_intersect(i))/2);
end
for i=1:5
    for j=1:sss(1)
        detect_lines(j,second_intersect(i)-1)=125;
        detect_lines(j,second_intersect(i))=125;
        detect_lines(j,second_intersect(i)+1)=125;
    end
end
average_distance_second_direction=0;
for i=1:4
    average_distance_second_direction=average_distance_second_direction+second_intersect(i+1)-second_intersect(i);
    edge_points_second(i+1)= round((second_intersect(i+1)+second_intersect(i))/2);
end
average_distance_second_direction=round(average_distance_second_direction/4);
edge_points_second(1)=round(second_intersect(1)-average_distance_second_direction/2);
edge_points_second(6)=round(second_intersect(5)+average_distance_second_direction/2);
%imshow(detect_lines)





modified_matrix=zeros(sss(1),sss(2),'uint8');
for i=1:5
    first_dic_cell_start_point=edge_points_first(i)-1;
    first_dic_cell_end_point=edge_points_first(i+1);
    for j=1:5
        second_dic_cell_start_point=edge_points_second(j)-1;
        second_dic_cell_end_point=edge_points_second(j+1);
        clear celll;
        celll=searchwindow(first_dic_cell_start_point:first_dic_cell_end_point,second_dic_cell_start_point:second_dic_cell_end_point);
        for k=1:1
            %size_cell=size(celll);
            %reduced_window=window(1:size_cell(1),1:size_cell(2));
            celll=(conv2(celll,window,'same'));
            celll=maap(celll);
            
            cell=celll;
            
        end
        for k=1:20
            celll=multiplyele2ele(celll,celll);
            celll=maap(celll);
        end
        modified_matrix(first_dic_cell_start_point:first_dic_cell_end_point,second_dic_cell_start_point:second_dic_cell_end_point,1)=cell;
        modified_matrix(first_dic_cell_start_point:first_dic_cell_end_point,second_dic_cell_start_point:second_dic_cell_end_point,2)=cell;
        modified_matrix(first_dic_cell_start_point:first_dic_cell_end_point,second_dic_cell_start_point:second_dic_cell_end_point,3)=cell;
        modified_matrix(first_dic_cell_start_point:first_dic_cell_end_point,second_dic_cell_start_point:second_dic_cell_end_point,2)=celll;
        maxxi=max(max(modified_matrix(first_dic_cell_start_point:first_dic_cell_end_point,second_dic_cell_start_point:second_dic_cell_end_point,2)));
        %clear firsttt;
        %clear seconddd;
        total_points=0;
        firsttt(i,j)=0;
        seconddd(i,j)=0;
        for gg=first_dic_cell_start_point:first_dic_cell_end_point
            for hh=second_dic_cell_start_point:second_dic_cell_end_point
                if modified_matrix(gg,hh,2)==maxxi
                    total_points=total_points+1;
                    firsttt(i,j)=firsttt(i,j)+gg;
                    seconddd(i,j)=seconddd(i,j)+hh;
                    
                    
                    
                    
        searchwindow_real(gg-1,hh,2)=155;
        searchwindow_real(gg,hh,2)=155;
        searchwindow_real(gg+1,hh,2)=155;
        searchwindow_real(gg,hh-1,2)=155;
        searchwindow_real(gg,hh+1,2)=155;
                end
            end
        end
        firsttt(i,j)=(round(firsttt(i,j)/total_points));
        seconddd(i,j)=(round(seconddd(i,j)/total_points));
        firsttt_for_xls((frameno-1)*5+i,j)=firsttt(i,j);
        seconddd_for_xls((frameno-1)*5+i,j)=seconddd(i,j);
        
        
        searchwindow_real(firsttt(i,j)-1,seconddd(i,j),1)=0;
        searchwindow_real(firsttt(i,j),seconddd(i,j),1)=0;
        searchwindow_real(firsttt(i,j)+1,seconddd(i,j),1)=0;
        searchwindow_real(firsttt(i,j),seconddd(i,j)-1,1)=0;
        searchwindow_real(firsttt(i,j),seconddd(i,j)+1,1)=0;
        searchwindow_real(firsttt(i,j)-1,seconddd(i,j),3)=0;
        searchwindow_real(firsttt(i,j),seconddd(i,j),3)=0;
        searchwindow_real(firsttt(i,j)+1,seconddd(i,j),3)=0;
        searchwindow_real(firsttt(i,j),seconddd(i,j)-1,3)=0;
        searchwindow_real(firsttt(i,j),seconddd(i,j)+1,3)=0;
        searchwindow_real(firsttt(i,j)-1,seconddd(i,j),2)=255;
        searchwindow_real(firsttt(i,j),seconddd(i,j),2)=255;
        searchwindow_real(firsttt(i,j)+1,seconddd(i,j),2)=255;
        searchwindow_real(firsttt(i,j),seconddd(i,j)-1,2)=255;
        searchwindow_real(firsttt(i,j),seconddd(i,j)+1,2)=255;
        
        
        
        
    end
end
%imshow(modified_matrix)
%imshow(searchwindow_real)
%imshow(RGB)
pause(.05)

end
imtool(searchwindow_real)
filenameeee= strcat('points_video3','.xlsx') ;
xlswrite(filenameeee,firsttt_for_xls,1)
xlswrite(filenameeee,seconddd_for_xls,2)